



 
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-86S09WJT92"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-86S09WJT92');
</script>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Dubai Medical College for Girls is the first college to award a degree in medicine & surgery in the UAE  " />
<meta name="keywords" content=" Bachelor in Medicine, Surgery, MBBCh, First Medical College in UAE,  MBBS, education,university,educational,learn,Dubai Medical College for Girls, Dubai, UAE, teaching,medical education, Professional Practice, Clinical, Biomedical Science,  Clinical Science, Health and Behavioral Sciences, Islamic values, research" />
<meta name="author" content="Dubai Medical College for Girls' IT Department" />

<!-- Page Title --> 
<title>Welcome to Dubai Medical College for Girls  - Open Access Journals</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link href="css/menuzord-megamenu.css" rel="stylesheet"/>
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
 <link rel="stylesheet" href="css/components/bs-datatable.css" type="text/css" />
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->
 

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-color-set3.css" rel="stylesheet" type="text/css">

<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>
 

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="has-fixed-footer">
<div id="wrapper" class="clearfix">  
  
  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top bg-theme-colored2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="widget text-white">
              <ul class="list-inline xs-text-center text-white">
                <li class="m-0 pl-10 pr-10"> <a href="#" class="text-white"><i class="fa fa-phone text-white"></i>+9714-2120555</a> </li>
                <li class="m-0 pl-10 pr-10"> 
                  <a href="#" class="text-white"><i class="fa fa-envelope-o text-white mr-5"></i> dmcg@dmcg.edu</a> 
                </li>
              </ul>
            </div>
          </div> 
          <div class="col-md-6">
            <ul class="list-inline sm-pull-none sm-text-center text-right text-white mb-sm-20 mt-10">
			<li> <a href="jobs.php" class="text-white">Careers</a> | </li>
			<li> <a href="https://dmcg.edu/helpdesk/" target="_blank"  class="text-white"> IT Helpdesk</a> | </li>
			<li class="dropdown">
                  <a href="#" class="dropdown-toggle text-white" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Campus Logins <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="https://dmug.brightspace.com/d2l/login" target="_blank"><i class="fa fa-graduation-cap mr-5"></i> LMS Login</a></li>
                    <!--<li><a href="#"><i class="fa fa-edit mr-5"></i> SIS Login</a></a></li>-->
                    <li><a href="https://www.office.com/?auth=2" target="_blank"><i class="fa fa-envelope mr-5"></i> Office 365</a></li> 
                    
                  </ul>
                </li>             
            </ul>
          </div>
        </div>
      </div>
    </div>    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default"><a class="menuzord-brand pull-left flip mt-sm-10 mb-sm-20" href="index.php"><img src="images/logo-dmc.png" alt=""></a>
            <ul class="menuzord-menu">
              <li><a href="index.php">Home</a> 
              </li>
              <li><a href="#">About Us </a>
                <ul class="dropdown">
                <li><a href="main.php?pageid=74&AboutDmcg">About DMCG</a></li>
                <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>				
				 <li><a href="main.php?pageid=13&DeansMessage">Dean's Message</a></li>
				 <li><a href="main.php?pageid=17&BoardTrustees">Board of Trustees</a></li>		 
				 <li><a href="main.php?pageid=73&Leadership">DMCG Leadership</a></li>
                 <li><a href="main.php?pageid=12&VisionMission">The Vision &amp; Mission</a></li>
				 <li><a href="main.php?pageid=16&GoalsObjectives">Goals and Objectives</a></li>	
				 <li><a href="main.php?pageid=15&CollegePublications">College Publications</a></li>
				 <li><a href="main.php?pageid=18&OrganizationStructure">Organization Structure</a></li>			 
				 <li><a href="main.php?pageid=14&AboutDubai">About Dubai</a></li>
                </ul>
              </li>
              <li><a href="#">Academics</a>
                <ul class="dropdown">
                  <li><a href="academics.php?pageid=22&ProgramLearning">MBBCH</a>
                    <ul class="dropdown">
					  <li><a href="#">Calendars</a>
					   <ul class="dropdown">
					   <li><a href="academics.php?pageid=19&AcademicCalendar">Academic Calendar</a></li>
                      <li><a href="academics.php?pageid=20&EventsCalendar">Events Calendar</a></li>
					  <li><a href="academics.php?pageid=85&ExaminationCalendar">Examination Calendar</a></li></ul>
					  </li> 
					  <!--<li><a href="academics.php?pageid=21&ProgramDetails">Program Details</a></li>-->
					  <li><a href="academics.php?pageid=22&ProgramLearning">Program Learning Outcomes</a></li>
					  <li><a href="academics.php?pageid=23&TeachingPlan">Teaching Plan</a></li>
					  <li><a href="academics.php?pageid=24&CourseDescription">Course Description</a></li>
					  <li><a href="academics.php?pageid=79&Timetables">Timetables</a></li>
					  <li><a href="academics.php?pageid=84&CourseCatalogue">Course Catalogue</a></li>
					  <li><a href="academics.php?pageid=87&StudyGuide">Study Guide</a></li>
					  <li><a href="academics.php?pageid=81&GraduationCriteria">Graduation Criteria</a></li>
					  <li><a href="academics.php?pageid=82&AcademicFaculty">Academic Faculty & Staff</a></li>
					  <li><a href="academics.php?pageid=83&AdjunctFaculty">Adjunct Faculty Manual</a></li>
                    </ul>
                  </li>                  
                </ul>
              </li> 
              <li><a href="#">Life At Campus</a>
                <ul class="dropdown">  
                  <li><a href="campus.php?pageid=51&Departments">Departments</a></li>
				  <li><a href="campus.php?pageid=75&StudentAffairs">Student Affairs</a>
                   <ul class="dropdown">                      
				    <li><a href="campus.php?pageid=36&CareerGuidance">Career Guidance</a></li> 
				 	<li><a href="campus.php?pageid=35&StudentCounselling">Student Counselling</a></li> 
				 	<li><a href="campus.php?pageid=76&StudentServices">Student Support Services</a></li> 
				 	<li><a href="campus.php?pageid=34&Hostel">Hostel Facilities</a></li> 			  
                    </ul>
                  </li>
				  <li><a href="campus.php?pageid=80&SimulationCenter">Simulation Center</a></li>
				   <li><a href="campus.php?pageid=32&LearningCenter">Learning Center</a></li>
                  <li><a href="campus.php?pageid=33&FacilitiesDHA">Facilities at DHA</a></li>
<li><a href="campus.php?pageid=78&TeachingFacilities">Teaching Facilities</a></li>
                </ul> 
              </li>
			  <li><a href="#">Research</a>
                <ul class="dropdown"> 
				 <!--<li><a href="research.php?pageid=37&Director+of+Research">Director of Research</a></li>--> 
				 <li><a href="research.php?pageid=38&AimofResearch">Aim of Research at DMCG</a></li>
				 <li><a href="research.php?pageid=39&ResearchCollaborations">Research Collaborations</a></li>
				 <li><a href="research.php?pageid=40&ResearchSupport">Research Support</a></li>
				 <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li>
				  <li><a href="research.php?pageid=42&Publications">DMCG Academic Publications</a></li>
				 <li><a href="research.php?pageid=45&Researchpolicy">Research Policy</a></li>
                </ul>
              </li>
			  <li class="active"><a href="#">Library</a>
                <ul class="dropdown">  
                  <li><a href="library.php?pageid=31&DMCGLibrary">DMCG Library</a></li>
				  <li><a href="library.php?pageid=47&EResources">E-Resources</a></li>
				  <li><a href="#">E-Journals</a>
				   <ul class="dropdown">
                      <li><a href="journals1.php">Medline Complete</a></li> 
					  <li><a href="journals3.php">Open Access Journals </a></li>
					  <li><a href="library.php?pageid=49&OtherJournals">Other Journals </a></li>
                    </ul></li>
                </ul> 
              </li>
			  <li><a href="#">Media</a>
                <ul class="dropdown"> 
                  <li><a href="announcements.php">Announcements</a></li>
                  <!--<li><a href="media.php?nncategory_id=1&News">News</a></li>-->
                  <li><a href="event.php?ecategory_id=1&DMCG Events">Events</a></li>
				 <li><a href="collegem.php">College Magazines</a></li> 
				 <li><a href="event.php?ecategory_id=2&DMCG Updates">DMCG Updates</a></li> 
                </ul>
              </li>
			  <li><a href="contact.php">Contact</a>               
              </li>
            </ul>
		          </nav>
        </div>
      </div>
    </div>
  </header>
  
 
  
  
 
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-white-7" data-bg-img="images/bg/bg4.jpg">
      <div class="container pt-50 pb-30">
        <!-- Section Content -->
        <div class="section-title">
          <div class="row"> 
            <div class="col-md-6 text-left flip xs-text-center">
              <h5 class="sub-title">Environment for Study </h5>
          <h2 class="title">Library</h2>
            </div>
            <div class="col-sm-4">
              <ol class="breadcrumb text-right sm-text-center text-black mt-10">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Library</a></li>
                <li class="active text-theme-colored">E-Journals</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
    
	
	
 <!-- Section: Course list -->
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-9 blog-pull-right">
		  <h3 class="text-uppercase line-bottom-theme-colored-2 line-height-1 mt-0 mt-sm-30"> Open Access Journals</h3>    
               
			   
			   


<table id='datatable1' class='table table-striped table-bordered' cellspacing='0' width='100%'>
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Journal Names</h3></th>
		<th>Link</th>
        <th>Access</th>
		<th>Language</th>
	  </tr>
    </thead>
	<tfoot>
      <tr>
        <th>Sr.No</th>
        <th>Journal Names</h3></th>
		<th>Link</th>
        <th>Access</th>
		<th>Language</th>
	  </tr>
    </tfoot>
    <tbody><tr><td>1</td><td>AAPS Open</td><td><a href=http://aapsopen.springeropen.com/ target='_blank'>http://aapsopen.springeropen.com/</td><td>Free site</td><td>English</td></tr><tr><td>2</td><td>ACS Medicinal Chemistry Letters</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2426/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2426/</td><td>After 1 year</td><td>English</td></tr><tr><td>3</td><td>Acta Pharmaceutica</td><td><a href=https://content.sciendo.com/view/journals/acph/acph-overview.xml target='_blank'>https://content.sciendo.com/view/journals/acph/acph-overview.xml</td><td>Free site</td><td>English</td></tr><tr><td>4</td><td>Acta Pharmaceutica Sinica B</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2814/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2814/</td><td>Free site</td><td>English</td></tr><tr><td>5</td><td>Acta Pharmacologica Sinica</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2405/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2405/</td><td>Free site</td><td>English</td></tr><tr><td>6</td><td>Actualidad en Farmacologia y Terapeutica</td><td><a href=http://www.socesfar.es/index.php/revista target='_blank'>http://www.socesfar.es/index.php/revista</td><td>Free site</td><td>Espanol</td></tr><tr><td>7</td><td>ADMET and DMPK</td><td><a href=http://pub.iapchem.org/ojs/index.php/admet/index target='_blank'>http://pub.iapchem.org/ojs/index.php/admet/index</td><td>Free site</td><td>English</td></tr><tr><td>8</td><td>Advanced Pharmaceutical Bulletin</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2246/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2246/</td><td>Free site</td><td>English</td></tr><tr><td>9</td><td>Advances in Biomedicine and Pharmacy</td><td><a href=http://www.thescientificpub.com/ target='_blank'>http://www.thescientificpub.com/</td><td>Free site</td><td>English</td></tr><tr><td>10</td><td>Advances in Pharmacoepidemiology and Drug Safety</td><td><a href=https://www.omicsonline.org/advances-in-pharmacoepidemiology-drug-safety.php target='_blank'>https://www.omicsonline.org/advances-in-pharmacoepidemiology-drug-safety.php</td><td>Free site</td><td>English</td></tr><tr><td>11</td><td>Advances in Pharmacological Sciences</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1381/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1381/</td><td>Free site</td><td>English</td></tr><tr><td>12</td><td>Advances in Pharmacology and Pharmacy</td><td><a href=http://www.hrpub.org/journals/jour_info.php?id=73 target='_blank'>http://www.hrpub.org/journals/jour_info.php?id=73</td><td>Free site</td><td>English</td></tr><tr><td>13</td><td>African Journal of Pharmacy and Pharmacology</td><td><a href=http://academicjournals.org/journal/AJPP target='_blank'>http://academicjournals.org/journal/AJPP</td><td>Free site</td><td>English</td></tr><tr><td>14</td><td>American Health & Drug Benefits</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2442/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2442/</td><td>Free site</td><td>English</td></tr><tr><td>15</td><td>American Journal of Advanced Drug Delivery</td><td><a href=http://www.imedpub.com/advanced-drug-delivery/ target='_blank'>http://www.imedpub.com/advanced-drug-delivery/</td><td>Free site</td><td>English</td></tr><tr><td>16</td><td>American Journal of Drug Discovery and Development</td><td><a href=https://scialert.net/jhome.php?issn=2150-427x target='_blank'>https://scialert.net/jhome.php?issn=2150-427x</td><td>Free site</td><td>English</td></tr><tr><td>17</td><td>American Journal of Pharmaceutical Education</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/383/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/383/</td><td>Free site</td><td>English</td></tr><tr><td>18</td><td>American Journal of Pharmacological Sciences</td><td><a href=http://www.sciepub.com/journal/ajps target='_blank'>http://www.sciepub.com/journal/ajps</td><td>Free site</td><td>English</td></tr><tr><td>19</td><td>American Journal of Pharmacology and Toxicology</td><td><a href=http://thescipub.com/journals/ajpt target='_blank'>http://thescipub.com/journals/ajpt</td><td>Free site</td><td>English</td></tr><tr><td>20</td><td>American Journal of Pharmacy and Health Research</td><td><a href=http://www.ajphr.com/ target='_blank'>http://www.ajphr.com/</td><td>Free site</td><td>English</td></tr><tr><td>21</td><td>Anales de la Real Academia Nacional de Farmacia</td><td><a href=http://www.analesranf.com/index.php/aranf target='_blank'>http://www.analesranf.com/index.php/aranf</td><td>Free site</td><td>Espanol/English</td></tr><tr><td>22</td><td>Archives of Pharmacy Practice</td><td><a href=http://www.archivepp.com/ target='_blank'>http://www.archivepp.com/</td><td>Free site</td><td>English</td></tr><tr><td>23</td><td>Ars Pharmaceutica</td><td><a href=http://scielo.isciii.es/scielo.php?script=sci_serial&pid=2340-9894&lng=es&nrm=iso target='_blank'>http://scielo.isciii.es/scielo.php?script=sci_serial&pid=2340-9894&lng=es&nrm=iso</td><td>Free site</td><td>Espanol/English</td></tr><tr><td>24</td><td>Asian Journal of Chemistry and Pharmaceutical Sciences</td><td><a href=http://www.informaticsjournals.com/index.php/ajcps target='_blank'>http://www.informaticsjournals.com/index.php/ajcps</td><td>Free site</td><td>English</td></tr><tr><td>25</td><td>Asian Journal of Pharmaceutical and Clinical Research</td><td><a href=http://innovareacademics.in/journals/index.php/ajpcr/index target='_blank'>http://innovareacademics.in/journals/index.php/ajpcr/index</td><td>Free site</td><td>English</td></tr><tr><td>26</td><td>Asian Journal of Pharmaceutical and Health Sciences</td><td><a href=http://ajphs.com/ target='_blank'>http://ajphs.com/</td><td>Free site</td><td>English</td></tr><tr><td>27</td><td>Asian Journal of Pharmaceutical Research and Development</td><td><a href=http://www.ajprd.com/index.php/journal target='_blank'>http://www.ajprd.com/index.php/journal</td><td>Free site</td><td>English</td></tr><tr><td>28</td><td>Asian Journal of Pharmaceutical Research and Health Care</td><td><a href=http://www.informaticsjournals.com/index.php/ajprhc target='_blank'>http://www.informaticsjournals.com/index.php/ajprhc</td><td>Free site</td><td>English</td></tr><tr><td>29</td><td>Asian Journal of Pharmaceutical Sciences</td><td><a href=https://www.sciencedirect.com/journal/asian-journal-of-pharmaceutical-sciences target='_blank'>https://www.sciencedirect.com/journal/asian-journal-of-pharmaceutical-sciences</td><td>Free site</td><td>English</td></tr><tr><td>30</td><td>Asian Journal of Pharmaceutical Technology and Innovation</td><td><a href=http://www.asianpharmtech.com/ target='_blank'>http://www.asianpharmtech.com/</td><td>Free site</td><td>English</td></tr><tr><td>31</td><td>Asian Journal of Pharmaceutics</td><td><a href=http://www.asiapharmaceutics.info/ target='_blank'>http://www.asiapharmaceutics.info/</td><td>Free site</td><td>English</td></tr><tr><td>32</td><td>Australian Prescriber</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2853/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2853/</td><td>Free site</td><td>English</td></tr><tr><td>33</td><td>Bangladesh Journal of Pharmacology</td><td><a href=http://www.banglajol.info/index.php/BJP target='_blank'>http://www.banglajol.info/index.php/BJP</td><td>Free site</td><td>English</td></tr><tr><td>34</td><td>Bangladesh Pharmaceutical Journal</td><td><a href=http://www.banglajol.info/index.php/BPJ target='_blank'>http://www.banglajol.info/index.php/BPJ</td><td>Free site</td><td>English</td></tr><tr><td>35</td><td>Basic, Applied Pharmacy and Pharmacology</td><td><a href=https://www.boffinaccess.com/journals/basic-applied-pharmacy-pharmacology/bapp target='_blank'>https://www.boffinaccess.com/journals/basic-applied-pharmacy-pharmacology/bapp</td><td>Free site</td><td>English</td></tr><tr><td>36</td><td>Biochemistry & Pharmacology: Open Access</td><td><a href=https://www.omicsonline.org/biochemistry-pharmacology-open-access.php target='_blank'>https://www.omicsonline.org/biochemistry-pharmacology-open-access.php</td><td>Free site</td><td>English</td></tr><tr><td>37</td><td>Biological and Pharmaceutical Bulletin</td><td><a href=https://www.jstage.jst.go.jp/browse/bpb target='_blank'>https://www.jstage.jst.go.jp/browse/bpb</td><td>Free site</td><td>English</td></tr><tr><td>38</td><td>Biologics: Targets & Therapy</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/923/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/923/</td><td>Free site</td><td>English</td></tr><tr><td>39</td><td>Biomedicines</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3168/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3168/</td><td>Free site</td><td>English</td></tr><tr><td>40</td><td>Biomolecules & Therapeutics</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2034/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2034/</td><td>Free site</td><td>English</td></tr><tr><td>41</td><td>Boletin de Informacion Farmacoterapeutica de Navarra</td><td><a href=http://www.navarra.es/home_es/Temas/Portal+de+la+Salud/Profesionales/Documentacion+y+publicaciones/Publicaciones+tematicas/Medicamento/BIT/ target='_blank'>http://www.navarra.es/home_es/Temas/Portal+de+la+Salud/Profesionales/Documentacion+y+publicaciones/Publicaciones+tematicas/Medicamento/BIT/</td><td>Free site</td><td>Espanol</td></tr><tr><td>42</td><td>Boletin Terapeutico Andaluz</td><td><a href=http://www.cadime.es/es/boletines_publicados.cfm target='_blank'>http://www.cadime.es/es/boletines_publicados.cfm</td><td>Free site</td><td>Espanol</td></tr><tr><td>43</td><td>Brazilian Journal of Pharmaceutical Sciences</td><td><a href=http://www.scielo.br/scielo.php?script=sci_serial&pid=1984-8250&lng=en&nrm=iso target='_blank'>http://www.scielo.br/scielo.php?script=sci_serial&pid=1984-8250&lng=en&nrm=iso</td><td>Free site</td><td>Portugues/English</td></tr><tr><td>44</td><td>British Journal of Clinical Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/279/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/279/</td><td>After 1 year</td><td>English</td></tr><tr><td>45</td><td>British Journal of Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/282/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/282/</td><td>After 1 year</td><td>English</td></tr><tr><td>46</td><td>Bulletin of Faculty of Pharmacy, Cairo University</td><td><a href=https://www.sciencedirect.com/journal/bulletin-of-faculty-of-pharmacy-cairo-university target='_blank'>https://www.sciencedirect.com/journal/bulletin-of-faculty-of-pharmacy-cairo-university</td><td>Free site</td><td>English</td></tr><tr><td>47</td><td>Bulletin of Pharmaceutical Research</td><td><a href=http://journal.appconnect.in/ target='_blank'>http://journal.appconnect.in/</td><td>Free site</td><td>English</td></tr><tr><td>48</td><td>Butlleti Groc</td><td><a href=https://www.icf.uab.cat/es/ficf/butlleti-groc target='_blank'>https://www.icf.uab.cat/es/ficf/butlleti-groc</td><td>Free site</td><td>Espanol</td></tr><tr><td>49</td><td>Canadian Journal of Hospital Pharmacy</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1115/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1115/</td><td>After 6 months</td><td>English</td></tr><tr><td>50</td><td>Canadian Pharmacists Journal : CPJ</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1856/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1856/</td><td>Free site</td><td>English</td></tr><tr><td>51</td><td>Chemical and Pharmaceutical Bulletin</td><td><a href=https://www.jstage.jst.go.jp/browse/cpb target='_blank'>https://www.jstage.jst.go.jp/browse/cpb</td><td>Free site</td><td>English</td></tr><tr><td>52</td><td>Chronicles of Pharmaceutical Science</td><td><a href=https://www.scientiaricerca.com/cops.php target='_blank'>https://www.scientiaricerca.com/cops.php</td><td>Free site</td><td>English</td></tr><tr><td>53</td><td>Clinical and Translational Science</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2996/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2996/</td><td>Free site</td><td>English</td></tr><tr><td>54</td><td>Clinical Medicine Insights: Therapeutics</td><td><a href=http://journals.sagepub.com/home/thp target='_blank'>http://journals.sagepub.com/home/thp</td><td>Free site</td><td>English</td></tr><tr><td>55</td><td>Clinical Pharmacology & Biopharmaceutics</td><td><a href=https://www.omicsonline.org/clinical-pharmacology-biopharmaceutics.php target='_blank'>https://www.omicsonline.org/clinical-pharmacology-biopharmaceutics.php</td><td>Free site</td><td>English</td></tr><tr><td>56</td><td>Clinical Pharmacology: Advances and Applications</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1697/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1697/</td><td>Free site</td><td>English</td></tr><tr><td>57</td><td>Core Evidence</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1264/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1264/</td><td>Free site</td><td>English</td></tr><tr><td>58</td><td>CPT: Pharmacometrics and Systems Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2038/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2038/</td><td>Free site</td><td>English</td></tr><tr><td>59</td><td>Current Issues in Pharmacy and Medical Sciences</td><td><a href=https://content.sciendo.com/view/journals/cipms/cipms-overview.xml target='_blank'>https://content.sciendo.com/view/journals/cipms/cipms-overview.xml</td><td>Free site</td><td>English</td></tr><tr><td>60</td><td>Current Therapeutic Research</td><td><a href=https://www.sciencedirect.com/science/journal/0011393X target='_blank'>https://www.sciencedirect.com/science/journal/0011393X</td><td>Free site</td><td>English</td></tr><tr><td>61</td><td>DARU Journal of Pharmaceutical Sciences</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1665/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1665/</td><td>Free site</td><td>English</td></tr><tr><td>62</td><td>Der Pharma Chemica</td><td><a href=http://derpharmachemica.com/ target='_blank'>http://derpharmachemica.com/</td><td>Free site</td><td>English</td></tr><tr><td>63</td><td>Der Pharmacia Lettre</td><td><a href=http://www.scholarsresearchlibrary.com/journals/der-pharmacia-lettre/ target='_blank'>http://www.scholarsresearchlibrary.com/journals/der-pharmacia-lettre/</td><td>Free site</td><td>English</td></tr><tr><td>64</td><td>Der Pharmacia Sinica</td><td><a href=http://www.imedpub.com/der-pharmacia-sinica/ target='_blank'>http://www.imedpub.com/der-pharmacia-sinica/</td><td>Free site</td><td>English</td></tr><tr><td>65</td><td>Dhaka University Journal of Pharmaceutical Sciences</td><td><a href=http://www.banglajol.info/index.php/JPharma target='_blank'>http://www.banglajol.info/index.php/JPharma</td><td>Free site</td><td>English</td></tr><tr><td>66</td><td>Drug Delivery</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3498/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3498/</td><td>Free site</td><td>English</td></tr><tr><td>67</td><td>Drug Design Development and Delivery Journal</td><td><a href=https://www.boffinaccess.com/journals/drug-design-development-and-delivery/ddddj target='_blank'>https://www.boffinaccess.com/journals/drug-design-development-and-delivery/ddddj</td><td>Free site</td><td>English</td></tr><tr><td>68</td><td>Drug Design, Development and Therapy</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/958/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/958/</td><td>Free site</td><td>English</td></tr><tr><td>69</td><td>Drug Designing: Open Access</td><td><a href=https://www.omicsonline.org/drug-designing.php target='_blank'>https://www.omicsonline.org/drug-designing.php</td><td>Free site</td><td>English</td></tr><tr><td>70</td><td>Drug Development and Therapeutics</td><td><a href=http://www.ddtjournal.org/ target='_blank'>http://www.ddtjournal.org/</td><td>Free site</td><td>English</td></tr><tr><td>71</td><td>Drug Discoveries & Therapeutics</td><td><a href=https://www.jstage.jst.go.jp/browse/ddt target='_blank'>https://www.jstage.jst.go.jp/browse/ddt</td><td>Free site</td><td>English</td></tr><tr><td>72</td><td>Drug Metabolism and Disposition</td><td><a href=http://dmd.aspetjournals.org/ target='_blank'>http://dmd.aspetjournals.org/</td><td>After 1 year</td><td>English</td></tr><tr><td>73</td><td>Drug Safety - Case Reports</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3063/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3063/</td><td>Free site</td><td>English</td></tr><tr><td>74</td><td>Drug Target Insights</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1514/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1514/</td><td>Free site</td><td>English</td></tr><tr><td>75</td><td>Drug, Healthcare and Patient Safety</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1519/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1519/</td><td>Free site</td><td>English</td></tr><tr><td>76</td><td>Drugs - Real World Outcomes</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3007/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3007/</td><td>Free site</td><td>English</td></tr><tr><td>77</td><td>Drugs in Context</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2260/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2260/</td><td>Free site</td><td>English</td></tr><tr><td>78</td><td>Drugs in R&D</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2559/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2559/</td><td>Free site</td><td>English</td></tr><tr><td>79</td><td>Egyptian Journal of Basic and Clinical Pharmacology</td><td><a href=http://www.kenzpub.com/journals/ejbcp/ target='_blank'>http://www.kenzpub.com/journals/ejbcp/</td><td>Free site</td><td>English</td></tr><tr><td>80</td><td>European Pharmaceutical Journal</td><td><a href=https://content.sciendo.com/view/journals/afpuc/afpuc-overview.xml target='_blank'>https://content.sciendo.com/view/journals/afpuc/afpuc-overview.xml</td><td>Free site</td><td>English</td></tr><tr><td>81</td><td>Farmacia Hospitalaria</td><td><a href=http://www.aulamedica.es/gdcr/index.php/fh/index target='_blank'>http://www.aulamedica.es/gdcr/index.php/fh/index</td><td>Free site</td><td>Espanol</td></tr><tr><td>82</td><td>Farmac�uticos Comunitarios</td><td><a href=http://farmaceuticoscomunitarios.org/ target='_blank'>http://farmaceuticoscomunitarios.org/</td><td>Free site</td><td>Espanol</td></tr><tr><td>83</td><td>Ficha de Evaluaci�n Terap�utica</td><td><a href=http://www.navarra.es/home_es/Temas/Portal+de+la+Salud/Profesionales/Documentacion+y+publicaciones/Publicaciones+tematicas/Medicamento/FET/listado.htm target='_blank'>http://www.navarra.es/home_es/Temas/Portal+de+la+Salud/Profesionales/Documentacion+y+publicaciones/Publicaciones+tematicas/Medicamento/FET/listado.htm</td><td>Free site</td><td>Espanol</td></tr><tr><td>84</td><td>Folia Pharmacotherapeutica</td><td><a href=http://www.cbip.be/fr/start target='_blank'>http://www.cbip.be/fr/start</td><td>Free site</td><td>Fran�ais</td></tr><tr><td>85</td><td>Frontiers in Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1524/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1524/</td><td>Free site</td><td>English</td></tr><tr><td>86</td><td>Future Journal of Pharmaceutical Sciences</td><td><a href=https://www.sciencedirect.com/journal/future-journal-of-pharmaceutical-sciences target='_blank'>https://www.sciencedirect.com/journal/future-journal-of-pharmaceutical-sciences</td><td>Free site</td><td>English</td></tr><tr><td>87</td><td>GaBI Journal</td><td><a href=http://gabi-journal.net/ target='_blank'>http://gabi-journal.net/</td><td>Free site</td><td>English</td></tr><tr><td>88</td><td>Hospital Pharmacology</td><td><a href=http://www.hophonline.org/ target='_blank'>http://www.hophonline.org/</td><td>Free site</td><td>English</td></tr><tr><td>89</td><td>Hospital Pharmacy</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2261/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2261/</td><td>After 1 year</td><td>English</td></tr><tr><td>90</td><td>Hygeia - Journal for Drugs and Medicines</td><td><a href=http://www.hygeiajournal.com/ target='_blank'>http://www.hygeiajournal.com/</td><td>Free site</td><td>English</td></tr><tr><td>91</td><td>In Silico Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2586/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2586/</td><td>Free site</td><td>English</td></tr><tr><td>92</td><td>Indian Journal of Pharmaceutical and Biological Research</td><td><a href=http://ijpbr.in/ target='_blank'>http://ijpbr.in/</td><td>Free site</td><td>English</td></tr><tr><td>93</td><td>Indian Journal of Pharmaceutical Sciences</td><td><a href=http://www.ijpsonline.com/ target='_blank'>http://www.ijpsonline.com/</td><td>Free site</td><td>English</td></tr><tr><td>94</td><td>Indian Journal of Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/979/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/979/</td><td>Free site</td><td>English</td></tr><tr><td>95</td><td>Indian Journal of Pharmacy and Pharmacology</td><td><a href=https://www.innovativepublication.com/journal_detail.php?jid=1 target='_blank'>https://www.innovativepublication.com/journal_detail.php?jid=1</td><td>Free site</td><td>English</td></tr><tr><td>96</td><td>Indian Journal of Physiology and Pharmacology</td><td><a href=http://www.ijpp.com/ target='_blank'>http://www.ijpp.com/</td><td>Free site</td><td>English</td></tr><tr><td>97</td><td>Indian Research Journal of Pharmacy and Science</td><td><a href=http://irjps.in/ target='_blank'>http://irjps.in/</td><td>Free site</td><td>English</td></tr><tr><td>98</td><td>Indo American Journal of Pharmaceutical Research</td><td><a href=http://www.iajpr.com/ target='_blank'>http://www.iajpr.com/</td><td>Free site</td><td>English</td></tr><tr><td>99</td><td>Indo American Journal of Pharmacy</td><td><a href=http://iajponline.com/ target='_blank'>http://iajponline.com/</td><td>Free site</td><td>English</td></tr><tr><td>100</td><td>Indonesian Journal of Pharmacy</td><td><a href=http://indonesianjpharm.farmasi.ugm.ac.id/index.php/3 target='_blank'>http://indonesianjpharm.farmasi.ugm.ac.id/index.php/3</td><td>Free site</td><td>English</td></tr><tr><td>101</td><td>Innovations in Pharmacy</td><td><a href=http://pubs.lib.umn.edu/innovations/ target='_blank'>http://pubs.lib.umn.edu/innovations/</td><td>Free site</td><td>English</td></tr><tr><td>102</td><td>Integrated Pharmacy Research and Practice</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3378/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3378/</td><td>Free site</td><td>English</td></tr><tr><td>103</td><td>International Bulletin of Drug Research</td><td><a href=http://www.ibdr.in/ target='_blank'>http://www.ibdr.in/</td><td>Free site</td><td>English</td></tr><tr><td>104</td><td>International Current Pharmaceutical Journal</td><td><a href=http://www.banglajol.info/index.php/ICPJ target='_blank'>http://www.banglajol.info/index.php/ICPJ</td><td>Free site</td><td>English</td></tr><tr><td>105</td><td>International Journal for Pharmaceutical Research Scholars</td><td><a href=http://ijprs.com/ target='_blank'>http://ijprs.com/</td><td>Free site</td><td>English</td></tr><tr><td>106</td><td>International Journal of advances in Pharmacy, Biology and Chemistry</td><td><a href=http://www.ijapbc.com/ target='_blank'>http://www.ijapbc.com/</td><td>Free site</td><td>English</td></tr><tr><td>107</td><td>International Journal of Applied Biology and Pharmaceutical Technology</td><td><a href=http://www.ijabpt.com/ target='_blank'>http://www.ijabpt.com/</td><td>Free site</td><td>English</td></tr><tr><td>108</td><td>International Journal of Basic & Clinical Pharmacology</td><td><a href=http://www.ijbcp.com/ target='_blank'>http://www.ijbcp.com/</td><td>Free site</td><td>English</td></tr><tr><td>109</td><td>International Journal of Basic Medical Sciences and Pharmacy</td><td><a href=https://www.ijbmsp.org/ target='_blank'>https://www.ijbmsp.org/</td><td>Free site</td><td>English</td></tr><tr><td>110</td><td>International Journal of Biology, Pharmacy and Allied Sciences</td><td><a href=http://www.ijbpas.com/ target='_blank'>http://www.ijbpas.com/</td><td>Free site</td><td>English</td></tr><tr><td>111</td><td>International Journal of Biopharmaceutical Sciences</td><td><a href=https://www.boffinaccess.com/journals/biopharmaceutical-sciences/ijbs target='_blank'>https://www.boffinaccess.com/journals/biopharmaceutical-sciences/ijbs</td><td>Free site</td><td>English</td></tr><tr><td>112</td><td>International Journal of Chemical and Pharmaceutical Analysis</td><td><a href=http://ijcpa.in/ target='_blank'>http://ijcpa.in/</td><td>Free site</td><td>English</td></tr><tr><td>113</td><td>International Journal of Chemistry and Pharmaceutical Sciences</td><td><a href=http://www.pharmaresearchlibrary.com/ijcps/ target='_blank'>http://www.pharmaresearchlibrary.com/ijcps/</td><td>Free site</td><td>English</td></tr><tr><td>114</td><td>International Journal of Drug Development and Research</td><td><a href=http://www.ijddr.in/ target='_blank'>http://www.ijddr.in/</td><td>Free site</td><td>English</td></tr><tr><td>115</td><td>International Journal of Drug Regulatory Affairs</td><td><a href=http://ijdra.com/index.php/journal target='_blank'>http://ijdra.com/index.php/journal</td><td>Free site</td><td>English</td></tr><tr><td>116</td><td>International Journal of Medicinal Chemistry</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2589/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2589/</td><td>Free site</td><td>English</td></tr><tr><td>117</td><td>International Journal of Pharma and Bio Sciences</td><td><a href=https://ijpbs.net/ target='_blank'>https://ijpbs.net/</td><td>Free site</td><td>English</td></tr><tr><td>118</td><td>International Journal of Pharma Research and Health Sciences</td><td><a href=http://www.pharmahealthsciences.net/ target='_blank'>http://www.pharmahealthsciences.net/</td><td>Free site</td><td>English</td></tr><tr><td>119</td><td>International Journal of Pharmaceutical and Biological Archive</td><td><a href=http://www.ijpba.info/ target='_blank'>http://www.ijpba.info/</td><td>Free site</td><td>English</td></tr><tr><td>120</td><td>International Journal of Pharmaceutical and Medicinal Research</td><td><a href=http://www.ijpmr.org/ target='_blank'>http://www.ijpmr.org/</td><td>Free site</td><td>English</td></tr><tr><td>121</td><td>International Journal of Pharmaceutical and Phytopharmacological Research</td><td><a href=https://www.eijppr.com/ target='_blank'>https://www.eijppr.com/</td><td>Free site</td><td>English</td></tr><tr><td>122</td><td>International Journal of Pharmaceutical Chemistry and Analysis</td><td><a href=https://www.innovativepublication.com/journal_detail.php?jid=4 target='_blank'>https://www.innovativepublication.com/journal_detail.php?jid=4</td><td>Free site</td><td>English</td></tr><tr><td>123</td><td>International Journal of Pharmaceutical Investigation</td><td><a href=http://www.jpionline.org/ target='_blank'>http://www.jpionline.org/</td><td>Free site</td><td>English</td></tr><tr><td>124</td><td>International Journal of Pharmaceutical Research and Allied Sciences</td><td><a href=http://ijpras.com/ target='_blank'>http://ijpras.com/</td><td>Free site</td><td>English</td></tr><tr><td>125</td><td>International Journal of Pharmaceutical Research and Bio-Science</td><td><a href=http://www.ijprbs.com/ target='_blank'>http://www.ijprbs.com/</td><td>Free site</td><td>English</td></tr><tr><td>126</td><td>International Journal of Pharmaceutical Science and Drug Research</td><td><a href=http://www.ijpsdr.com/ target='_blank'>http://www.ijpsdr.com/</td><td>Free site</td><td>English</td></tr><tr><td>127</td><td>International Journal of Pharmaceutical Sciences and Health Care</td><td><a href=http://rspublication.com/ijphc/index.html target='_blank'>http://rspublication.com/ijphc/index.html</td><td>Free site</td><td>English</td></tr><tr><td>128</td><td>International Journal of Pharmaceutical Sciences and Research</td><td><a href=http://ijpsr.com/ target='_blank'>http://ijpsr.com/</td><td>Free site</td><td>English</td></tr><tr><td>129</td><td>International Journal of Pharmaceutical Sciences Review and Research</td><td><a href=http://www.globalresearchonline.net/ target='_blank'>http://www.globalresearchonline.net/</td><td>Free site</td><td>English</td></tr><tr><td>130</td><td>International Journal of Pharmaceutical, Chemical and Biological Sciences</td><td><a href=http://www.ijpcbs.com/ target='_blank'>http://www.ijpcbs.com/</td><td>Free site</td><td>English</td></tr><tr><td>131</td><td>International Journal of Pharmaceutics & Pharmacology</td><td><a href=http://ijpp.edwiserinternational.com/home.php target='_blank'>http://ijpp.edwiserinternational.com/home.php</td><td>Free site</td><td>English</td></tr><tr><td>132</td><td>International Journal of Pharmacology</td><td><a href=https://scialert.net/jhome.php?issn=1811-7775 target='_blank'>https://scialert.net/jhome.php?issn=1811-7775</td><td>Free site</td><td>English</td></tr><tr><td>133</td><td>International Journal of Pharmacy and Chemistry</td><td><a href=http://www.sciencepublishinggroup.com/journal/index?journalid=330 target='_blank'>http://www.sciencepublishinggroup.com/journal/index?journalid=330</td><td>Free site</td><td>English</td></tr><tr><td>134</td><td>International Journal of Pharmacy and Pharmaceutical Research</td><td><a href=http://ijppr.humanjournals.com/ target='_blank'>http://ijppr.humanjournals.com/</td><td>Free site</td><td>English</td></tr><tr><td>135</td><td>International Journal of Pharmacy and Technology</td><td><a href=http://www.ijptonline.com/ target='_blank'>http://www.ijptonline.com/</td><td>Free site</td><td>English</td></tr><tr><td>136</td><td>International Journal of Pharmacy Research</td><td><a href=http://www.ijpr.in/ target='_blank'>http://www.ijpr.in/</td><td>Free site</td><td>English</td></tr><tr><td>137</td><td>International Journal of PharmTech Research</td><td><a href=http://www.sphinxsai.com/pharmtech.php target='_blank'>http://www.sphinxsai.com/pharmtech.php</td><td>Free site</td><td>English</td></tr><tr><td>138</td><td>International Journal of Research and Development in Pharmacy & Life Sciences</td><td><a href=http://www.ijrdpl.com/ target='_blank'>http://www.ijrdpl.com/</td><td>Free site</td><td>English</td></tr><tr><td>139</td><td>International Journal of Research in Pharmacology & Pharmacotherapeutics</td><td><a href=http://www.ijrpp.com/ target='_blank'>http://www.ijrpp.com/</td><td>Free site</td><td>English</td></tr><tr><td>140</td><td>International Journal of Research in Pharmacy and Chemistry</td><td><a href=http://www.ijrpc.com/ target='_blank'>http://www.ijrpc.com/</td><td>Free site</td><td>English</td></tr><tr><td>141</td><td>International Research Journal of Pharmacy</td><td><a href=http://www.irjponline.com/ target='_blank'>http://www.irjponline.com/</td><td>Free site</td><td>English</td></tr><tr><td>142</td><td>IP International Journal of Comprehensive and Advanced Pharmacology</td><td><a href=https://www.innovativepublication.com/journal_detail.php?jid=62 target='_blank'>https://www.innovativepublication.com/journal_detail.php?jid=62</td><td>Free site</td><td>English</td></tr><tr><td>143</td><td>Iranian Journal of Pharmaceutical Research</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2163/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2163/</td><td>Free site</td><td>English</td></tr><tr><td>144</td><td>Iraqi Journal of Pharmaceutical Sciences</td><td><a href=http://bijps.com/index.php/bijps target='_blank'>http://bijps.com/index.php/bijps</td><td>Free site</td><td>English</td></tr><tr><td>145</td><td>Istanbul Journal of Pharmacy</td><td><a href=http://dergipark.gov.tr/iujp target='_blank'>http://dergipark.gov.tr/iujp</td><td>Free site</td><td>English</td></tr><tr><td>146</td><td>Journal of Advanced Pharmaceutical Technology & Research</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1663/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1663/</td><td>Free site</td><td>English</td></tr><tr><td>147</td><td>Journal of Advanced Pharmacy Education & Research</td><td><a href=http://www.japer.in/ target='_blank'>http://www.japer.in/</td><td>Free site</td><td>English</td></tr><tr><td>148</td><td>Journal of Applied Pharmaceutical Research (JOAPR)</td><td><a href=http://www.japtronline.com/index.php/JOAPR target='_blank'>http://www.japtronline.com/index.php/JOAPR</td><td>Free site</td><td>English</td></tr><tr><td>149</td><td>Journal of Applied Pharmaceutical Science</td><td><a href=http://www.japsonline.com/ target='_blank'>http://www.japsonline.com/</td><td>Free site</td><td>English</td></tr><tr><td>150</td><td>Journal of Applied Pharmaceutical Sciences</td><td><a href=http://japhac.wixsite.com/japhac target='_blank'>http://japhac.wixsite.com/japhac</td><td>Free site</td><td>Portugues/English</td></tr><tr><td>151</td><td>Journal of Applied Pharmaceutical Sciences and Research</td><td><a href=http://www.japsr.in/ target='_blank'>http://www.japsr.in/</td><td>Free site</td><td>English</td></tr><tr><td>152</td><td>Journal of Applied Pharmacy</td><td><a href=https://www.omicsonline.org/applied-pharmacy.php target='_blank'>https://www.omicsonline.org/applied-pharmacy.php</td><td>Free site</td><td>English</td></tr><tr><td>153</td><td>Journal of Atoms and Molecules</td><td><a href=http://jamonline.in/ target='_blank'>http://jamonline.in/</td><td>Free site</td><td>English</td></tr><tr><td>154</td><td>Journal of Basic and Clinical Pharmacy</td><td><a href=http://www.jbclinpharm.org/ target='_blank'>http://www.jbclinpharm.org/</td><td>Free site</td><td>English</td></tr><tr><td>155</td><td>Journal of Bioequivalence & Bioavailability</td><td><a href=https://www.omicsonline.org/bioequivalence-bioavailability.php target='_blank'>https://www.omicsonline.org/bioequivalence-bioavailability.php</td><td>Free site</td><td>English</td></tr><tr><td>156</td><td>Journal of Bioequivalence Studies</td><td><a href=http://www.annexpublishers.com/journals/journal-of-bioequivalence-studies/jhome.php target='_blank'>http://www.annexpublishers.com/journals/journal-of-bioequivalence-studies/jhome.php</td><td>Free site</td><td>English</td></tr><tr><td>157</td><td>Journal of Biomedical and Pharmaceutical Research</td><td><a href=http://jbpr.in/ target='_blank'>http://jbpr.in/</td><td>Free site</td><td>English</td></tr><tr><td>158</td><td>Journal of Biomolecular Research & Therapeutics</td><td><a href=https://www.omicsonline.org/biomolecular-research-therapeutics.php target='_blank'>https://www.omicsonline.org/biomolecular-research-therapeutics.php</td><td>Free site</td><td>English</td></tr><tr><td>159</td><td>Journal of Chemical and Pharmaceutical Research</td><td><a href=http://www.jocpr.com/ target='_blank'>http://www.jocpr.com/</td><td>Free site</td><td>English</td></tr><tr><td>160</td><td>Journal of Chemical Biology & Therapeutics</td><td><a href=https://www.omicsonline.org/chemical-biology-therapeutics.php target='_blank'>https://www.omicsonline.org/chemical-biology-therapeutics.php</td><td>Free site</td><td>English</td></tr><tr><td>161</td><td>Journal of Chinese Pharmaceutical Sciences</td><td><a href=http://www.jcps.ac.cn/EN/volumn/current.shtml target='_blank'>http://www.jcps.ac.cn/EN/volumn/current.shtml</td><td>Free site</td><td>English</td></tr><tr><td>162</td><td>Journal of Clinical & Experimental Pharmacology</td><td><a href=https://www.omicsonline.org/clinical-experimental-pharmacology.php target='_blank'>https://www.omicsonline.org/clinical-experimental-pharmacology.php</td><td>Free site</td><td>English</td></tr><tr><td>163</td><td>Journal of Developing Drugs</td><td><a href=https://www.omicsonline.org/developing-drugs.php target='_blank'>https://www.omicsonline.org/developing-drugs.php</td><td>Free site</td><td>English</td></tr><tr><td>164</td><td>Journal of Drug Assessment</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2957/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2957/</td><td>Free site</td><td>English</td></tr><tr><td>165</td><td>Journal of Drug Delivery</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1491/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1491/</td><td>Free site</td><td>English</td></tr><tr><td>166</td><td>Journal of Drug Delivery and Therapeutics</td><td><a href=http://jddtonline.info/index.php/jddt target='_blank'>http://jddtonline.info/index.php/jddt</td><td>Free site</td><td>English</td></tr><tr><td>167</td><td>Journal of Drug Design and Medicinal Chemistry</td><td><a href=http://www.sciencepublishinggroup.com/journal/index?journalid=329 target='_blank'>http://www.sciencepublishinggroup.com/journal/index?journalid=329</td><td>Free site</td><td>English</td></tr><tr><td>168</td><td>Journal of Drug Metabolism & Toxicology</td><td><a href=https://www.omicsonline.org/drug-metabolism-toxicology.php target='_blank'>https://www.omicsonline.org/drug-metabolism-toxicology.php</td><td>Free site</td><td>English</td></tr><tr><td>169</td><td>Journal of Enzyme Inhibition and Medicinal Chemistry</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3428/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3428/</td><td>Free site</td><td>English</td></tr><tr><td>170</td><td>Journal of Experimental Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2982/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2982/</td><td>Free site</td><td>English</td></tr><tr><td>171</td><td>Journal of Global Pharma Technology</td><td><a href=http://www.jgpt.co.in/ target='_blank'>http://www.jgpt.co.in/</td><td>Free site</td><td>English</td></tr><tr><td>172</td><td>Journal of Global Trends in Pharmaceutical Sciences</td><td><a href=http://www.jgtps.com/ target='_blank'>http://www.jgtps.com/</td><td>Free site</td><td>English</td></tr><tr><td>173</td><td>Journal of In Silico & In Vitro Pharmacology</td><td><a href=http://pharmacology.imedpub.com/ target='_blank'>http://pharmacology.imedpub.com/</td><td>Free site</td><td>English</td></tr><tr><td>174</td><td>Journal of Medicinal and Chemical Sciences</td><td><a href=http://jmchemsci.com/ target='_blank'>http://jmchemsci.com/</td><td>Free site</td><td>English</td></tr><tr><td>175</td><td>Journal of Pharmaceutical & Health Sciences</td><td><a href=http://www.jphs.ir/ target='_blank'>http://www.jphs.ir/</td><td>Free site</td><td>English</td></tr><tr><td>176</td><td>Journal of Pharmaceutical Analysis</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3328/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3328/</td><td>Free site</td><td>English</td></tr><tr><td>177</td><td>Journal of Pharmaceutical and Biological Sciences</td><td><a href=https://www.innovativepublication.com/journal_detail.php?jid=72 target='_blank'>https://www.innovativepublication.com/journal_detail.php?jid=72</td><td>Free site</td><td>English</td></tr><tr><td>178</td><td>Journal of Pharmaceutical and Scientific Innovation</td><td><a href=http://jpsionline.com/ target='_blank'>http://jpsionline.com/</td><td>Free site</td><td>English</td></tr><tr><td>179</td><td>Journal of Pharmaceutical Care & Health Systems</td><td><a href=https://www.omicsonline.org/pharmaceutical-care-and-health-systems-open-access.php target='_blank'>https://www.omicsonline.org/pharmaceutical-care-and-health-systems-open-access.php</td><td>Free site</td><td>English</td></tr><tr><td>180</td><td>Journal of Pharmaceutical Health Care and Sciences</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2871/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2871/</td><td>Free site</td><td>English</td></tr><tr><td>181</td><td>Journal of Pharmaceutical Policy and Practice</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2376/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2376/</td><td>Free site</td><td>English</td></tr><tr><td>182</td><td>Journal of Pharmaceutical Research</td><td><a href=http://www.journalofpharmaceuticalresearch.org/ target='_blank'>http://www.journalofpharmaceuticalresearch.org/</td><td>Free site</td><td>English</td></tr><tr><td>183</td><td>Journal of Pharmaceutical Research & Clinical Practice</td><td><a href=http://www.jprcp.com/ target='_blank'>http://www.jprcp.com/</td><td>Free site</td><td>English</td></tr><tr><td>184</td><td>Journal of Pharmaceutical Research International</td><td><a href=http://www.sciencedomain.org/journal/64 target='_blank'>http://www.sciencedomain.org/journal/64</td><td>Free site</td><td>English</td></tr><tr><td>185</td><td>Journal of Pharmaceutical Science and Bioscientific Research</td><td><a href=http://www.jpsbr.org/ target='_blank'>http://www.jpsbr.org/</td><td>Free site</td><td>English</td></tr><tr><td>186</td><td>Journal of Pharmaceutical, Chemical and Biological Sciences</td><td><a href=http://www.jpcbs.info/ target='_blank'>http://www.jpcbs.info/</td><td>Free site</td><td>English</td></tr><tr><td>187</td><td>Journal of Pharmaceutics</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2825/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2825/</td><td>Free site</td><td>English</td></tr><tr><td>188</td><td>Journal of Pharmaceutics & Drug Development</td><td><a href=http://www.annexpublishers.com/journals/journal-of-pharmaceutics-and-drugs-development/jhome.php target='_blank'>http://www.annexpublishers.com/journals/journal-of-pharmaceutics-and-drugs-development/jhome.php</td><td>Free site</td><td>English</td></tr><tr><td>189</td><td>Journal of Pharmaceutics and Therapeutics</td><td><a href=http://www.gratisoa.org/journals/index.php/JPT target='_blank'>http://www.gratisoa.org/journals/index.php/JPT</td><td>Free site</td><td>English</td></tr><tr><td>190</td><td>Journal of Pharmacogenomics & Pharmacoproteomics</td><td><a href=https://www.omicsonline.org/pharmacogenomics-pharmacoproteomics.php target='_blank'>https://www.omicsonline.org/pharmacogenomics-pharmacoproteomics.php</td><td>Free site</td><td>English</td></tr><tr><td>191</td><td>Journal of Pharmacological Sciences</td><td><a href=https://www.sciencedirect.com/journal/journal-of-pharmacological-sciences target='_blank'>https://www.sciencedirect.com/journal/journal-of-pharmacological-sciences</td><td>Free site</td><td>English</td></tr><tr><td>192</td><td>Journal of Pharmacology and Experimental Therapeutics</td><td><a href=http://jpet.aspetjournals.org/ target='_blank'>http://jpet.aspetjournals.org/</td><td>After 1 year</td><td>English</td></tr><tr><td>193</td><td>Journal of Pharmacology and Pharmacotherapeutics</td><td><a href=http://www.jpharmacol.com/ target='_blank'>http://www.jpharmacol.com/</td><td>Free site</td><td>English</td></tr><tr><td>194</td><td>Journal of Pharmacovigilance</td><td><a href=https://www.omicsonline.org/pharmacovigilance.php target='_blank'>https://www.omicsonline.org/pharmacovigilance.php</td><td>Free site</td><td>English</td></tr><tr><td>195</td><td>Journal of Pharmacy & Pharmacognosy Research</td><td><a href=http://jppres.com/jppres/ target='_blank'>http://jppres.com/jppres/</td><td>Free site</td><td>English</td></tr><tr><td>196</td><td>Journal of Pharmacy and Bioallied Sciences</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1376/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1376/</td><td>Free site</td><td>English</td></tr><tr><td>197</td><td>Journal of Pharmacy and Pharmaceutical Research</td><td><a href=http://www.imedpub.com/journal-pharmacy-and-pharmaceutical-research/ target='_blank'>http://www.imedpub.com/journal-pharmacy-and-pharmaceutical-research/</td><td>Free site</td><td>English</td></tr><tr><td>198</td><td>Journal of Pharmacy and Pharmaceutical Sciences</td><td><a href=https://journals.library.ualberta.ca/jpps/index.php/jpps/index target='_blank'>https://journals.library.ualberta.ca/jpps/index.php/jpps/index</td><td>Free site</td><td>English</td></tr><tr><td>199</td><td>Journal of Pharmacy Practice and Community Medicine</td><td><a href=http://www.jppcm.org/ target='_blank'>http://www.jppcm.org/</td><td>Free site</td><td>English</td></tr><tr><td>200</td><td>Journal of Pharmacy Technology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3337/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3337/</td><td>After 1 year</td><td>English</td></tr><tr><td>201</td><td>Journal of PharmaSciTech</td><td><a href=http://www.pharmascitech.in/ target='_blank'>http://www.pharmascitech.in/</td><td>Free site</td><td>English</td></tr><tr><td>202</td><td>Journal of Population Therapeutics and Clinical Pharmacology</td><td><a href=http://www.jptcp.com/ target='_blank'>http://www.jptcp.com/</td><td>Free site</td><td>English</td></tr><tr><td>203</td><td>Journal of Research in Pharmacy</td><td><a href=http://www.jrespharm.com/ target='_blank'>http://www.jrespharm.com/</td><td>Free site</td><td>English</td></tr><tr><td>204</td><td>Journal of Research in Pharmacy Practice</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2402/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2402/</td><td>Free site</td><td>English</td></tr><tr><td>205</td><td>Journal of Xenobiotics</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3588/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3588/</td><td>Free site</td><td>English</td></tr><tr><td>206</td><td>Journal of Young Pharmacists</td><td><a href=http://www.jyoungpharm.org/ target='_blank'>http://www.jyoungpharm.org/</td><td>Free site</td><td>English</td></tr><tr><td>207</td><td>Korean Journal of Physiology & Pharmacology</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/972/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/972/</td><td>Free site</td><td>English</td></tr><tr><td>208</td><td>Matrix Science Pharma</td><td><a href=https://www.zibelinepub.com/index.php/matrix-science-pharma-msp/ target='_blank'>https://www.zibelinepub.com/index.php/matrix-science-pharma-msp/</td><td>Free site</td><td>English</td></tr><tr><td>209</td><td>MedChemComm</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3451/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3451/</td><td>After 1 year</td><td>English</td></tr><tr><td>210</td><td>Medicinal Chemistry</td><td><a href=https://www.omicsonline.org/medicinal-chemistry.php target='_blank'>https://www.omicsonline.org/medicinal-chemistry.php</td><td>Free site</td><td>English</td></tr><tr><td>211</td><td>Medicine Access @ Point of Care</td><td><a href=http://journals.sagepub.com/home/map target='_blank'>http://journals.sagepub.com/home/map</td><td>Free site</td><td>English</td></tr><tr><td>212</td><td>Medicines Safety Update</td><td><a href=http://www.tga.gov.au/publication/medicines-safety-update target='_blank'>http://www.tga.gov.au/publication/medicines-safety-update</td><td>Free site</td><td>English</td></tr><tr><td>213</td><td>Mintage Journal of Pharmaceutical and Medical Sciences</td><td><a href=http://www.mintagejournals.com/ target='_blank'>http://www.mintagejournals.com/</td><td>Free site</td><td>English</td></tr><tr><td>214</td><td>Molecular Pharmacology</td><td><a href=http://molpharm.aspetjournals.org/ target='_blank'>http://molpharm.aspetjournals.org/</td><td>After 1 year</td><td>English</td></tr><tr><td>215</td><td>Open Bioactive Compounds Journal</td><td><a href=https://openbioactivecompoundjournal.com/ target='_blank'>https://openbioactivecompoundjournal.com/</td><td>Free site</td><td>English</td></tr><tr><td>216</td><td>Open Journal of Medicinal Chemistry</td><td><a href=http://www.scirp.org/journal/ojmc/ target='_blank'>http://www.scirp.org/journal/ojmc/</td><td>Free site</td><td>English</td></tr><tr><td>217</td><td>Open Medicinal Chemistry Journal</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/927/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/927/</td><td>Free site</td><td>English</td></tr><tr><td>218</td><td>Open Pharmaceutical Sciences Journal</td><td><a href=https://openpharmaceuticalsciencesjournal.com/ target='_blank'>https://openpharmaceuticalsciencesjournal.com/</td><td>Free site</td><td>English</td></tr><tr><td>219</td><td>Open Pharmacology Journal</td><td><a href=https://openpharmacologyjournal.com/ target='_blank'>https://openpharmacologyjournal.com/</td><td>Free site</td><td>English</td></tr><tr><td>220</td><td>Perspectives in Medicinal Chemistry</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/954/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/954/</td><td>Free site</td><td>English</td></tr><tr><td>221</td><td>Pharma Innovation</td><td><a href=http://www.thepharmajournal.com/ target='_blank'>http://www.thepharmajournal.com/</td><td>Free site</td><td>English</td></tr><tr><td>222</td><td>Pharma Science Monitor</td><td><a href=http://www.pharmasm.com/ target='_blank'>http://www.pharmasm.com/</td><td>Free site</td><td>English</td></tr><tr><td>223</td><td>Pharmaceutica Analytica Acta</td><td><a href=https://www.omicsonline.org/pharmaceutica-analytica-acta.php target='_blank'>https://www.omicsonline.org/pharmaceutica-analytica-acta.php</td><td>Free site</td><td>English</td></tr><tr><td>224</td><td>Pharmaceutical Analytical Chemistry</td><td><a href=https://www.omicsonline.org/pharmaceutical-analytical-chemistry.php target='_blank'>https://www.omicsonline.org/pharmaceutical-analytical-chemistry.php</td><td>Free site</td><td>English</td></tr><tr><td>225</td><td>Pharmaceutical and Biomedical Research</td><td><a href=http://pbr.mazums.ac.ir/ target='_blank'>http://pbr.mazums.ac.ir/</td><td>Free site</td><td>English</td></tr><tr><td>226</td><td>Pharmaceutical and Chemical Journal</td><td><a href=http://tpcj.org/ target='_blank'>http://tpcj.org/</td><td>Free site</td><td>English</td></tr><tr><td>227</td><td>Pharmaceutical Bioprocessing</td><td><a href=http://www.openaccessjournals.com/journals/pharmaceutical-bioprocessing.html target='_blank'>http://www.openaccessjournals.com/journals/pharmaceutical-bioprocessing.html</td><td>Free site</td><td>English</td></tr><tr><td>228</td><td>Pharmaceutical Regulatory Affairs: Open Access</td><td><a href=https://www.omicsonline.org/pharmaceutical-regulatory-affairs-open-access.php target='_blank'>https://www.omicsonline.org/pharmaceutical-regulatory-affairs-open-access.php</td><td>Free site</td><td>English</td></tr><tr><td>229</td><td>Pharmaceutical Science and Technology</td><td><a href=http://www.sciencepublishinggroup.com/journal/index?journalid=515 target='_blank'>http://www.sciencepublishinggroup.com/journal/index?journalid=515</td><td>Free site</td><td>English</td></tr><tr><td>230</td><td>Pharmaceutical Technology in Hospital Pharmacy</td><td><a href=https://www.degruyter.com/view/j/pthp target='_blank'>https://www.degruyter.com/view/j/pthp</td><td>Free site</td><td>English</td></tr><tr><td>231</td><td>Pharmaceuticals</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2102/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2102/</td><td>Free site</td><td>English</td></tr><tr><td>232</td><td>Pharmaceutics</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2103/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2103/</td><td>Free site</td><td>English</td></tr><tr><td>233</td><td>PharmacoEconomics - Open</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3284/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3284/</td><td>Free site</td><td>English</td></tr><tr><td>234</td><td>Pharmacoeconomics: Open Access</td><td><a href=https://www.omicsonline.org/pharmacoeconomics-open-access.php target='_blank'>https://www.omicsonline.org/pharmacoeconomics-open-access.php</td><td>Free site</td><td>English</td></tr><tr><td>235</td><td>Pharmacogenomics and Personalized Medicine</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1956/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1956/</td><td>Free site</td><td>English</td></tr><tr><td>236</td><td>Pharmacology & Pharmacy</td><td><a href=http://www.scirp.org/journal/pp/ target='_blank'>http://www.scirp.org/journal/pp/</td><td>Free site</td><td>English</td></tr><tr><td>237</td><td>Pharmacology and Clinical Pharmacy Research</td><td><a href=http://jurnal.unpad.ac.id/pcpr/index target='_blank'>http://jurnal.unpad.ac.id/pcpr/index</td><td>Free site</td><td>English</td></tr><tr><td>238</td><td>Pharmacology Research & Perspectives</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2563/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2563/</td><td>Free site</td><td>English</td></tr><tr><td>239</td><td>Pharmacologyonline</td><td><a href=http://pharmacologyonline.silae.it/ target='_blank'>http://pharmacologyonline.silae.it/</td><td>Free site</td><td>English</td></tr><tr><td>240</td><td>Pharmacophore</td><td><a href=http://www.pharmacophorejournal.com/ target='_blank'>http://www.pharmacophorejournal.com/</td><td>Free site</td><td>English</td></tr><tr><td>241</td><td>Pharmactuel</td><td><a href=http://www.pharmactuel.com/ target='_blank'>http://www.pharmactuel.com/</td><td>Free site</td><td>Francais</td></tr><tr><td>242</td><td>Pharmacy</td><td><a href=http://www.mdpi.com/journal/pharmacy target='_blank'>http://www.mdpi.com/journal/pharmacy</td><td>Free site</td><td>English</td></tr><tr><td>243</td><td>Pharmacy and Therapeutics</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/809/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/809/</td><td>After 1 month</td><td>English</td></tr><tr><td>244</td><td>Pharmacy Practice</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2167/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2167/</td><td>Free site</td><td>English</td></tr><tr><td>245</td><td>Pharmacy Times</td><td><a href=http://www.pharmacytimes.com/ target='_blank'>http://www.pharmacytimes.com/</td><td>Free site</td><td>English</td></tr><tr><td>246</td><td>Pharmacy: Journal of Pharmacy Education and Practice</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3194/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3194/</td><td>Free site</td><td>English</td></tr><tr><td>247</td><td>Pharmazeutische Zeitung Online</td><td><a href=http://www.pharmazeutische-zeitung.de/ target='_blank'>http://www.pharmazeutische-zeitung.de/</td><td>Free site</td><td>Deutsch</td></tr><tr><td>248</td><td>Prescriber Update</td><td><a href=http://www.medsafe.govt.nz/Profs/PUarticles.asp target='_blank'>http://www.medsafe.govt.nz/Profs/PUarticles.asp</td><td>Free site</td><td>English</td></tr><tr><td>249</td><td>Research & Reviews in Pharmacy and Pharmaceutical Sciences</td><td><a href=http://www.rroij.com/pharmacy-and-pharmaceutical-sciences.php target='_blank'>http://www.rroij.com/pharmacy-and-pharmaceutical-sciences.php</td><td>Free site</td><td>English</td></tr><tr><td>250</td><td>Research & Reviews: Journal of Hospital and Clinical Pharmacy</td><td><a href=http://www.rroij.com/hospital-and-clinical-pharmacy.php target='_blank'>http://www.rroij.com/hospital-and-clinical-pharmacy.php</td><td>Free site</td><td>English</td></tr><tr><td>251</td><td>Research & Reviews: Journal of Pharmacology and Toxicological Studies</td><td><a href=http://www.rroij.com/pharmacology-and-toxicological-studies.php target='_blank'>http://www.rroij.com/pharmacology-and-toxicological-studies.php</td><td>Free site</td><td>English</td></tr><tr><td>252</td><td>Research in Pharmaceutical Sciences</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1515/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1515/</td><td>Free site</td><td>English</td></tr><tr><td>253</td><td>Research in Pharmacy</td><td><a href=http://updatepublishing.com/journal/index.php/rip/ target='_blank'>http://updatepublishing.com/journal/index.php/rip/</td><td>Free site</td><td>English</td></tr><tr><td>254</td><td>Research Journal of Pharmaceutical, Biological and Chemical Sciences</td><td><a href=http://www.rjpbcs.com/ target='_blank'>http://www.rjpbcs.com/</td><td>Free site</td><td>English</td></tr><tr><td>255</td><td>Research Journal of Pharmacology</td><td><a href=http://www.medwelljournals.com/journalhome.php?jid=1815-9362 target='_blank'>http://www.medwelljournals.com/journalhome.php?jid=1815-9362</td><td>Free site</td><td>English</td></tr><tr><td>256</td><td>Research Results in Pharmacology</td><td><a href=https://rrpharmacology.pensoft.net/ target='_blank'>https://rrpharmacology.pensoft.net/</td><td>Free site</td><td>English</td></tr><tr><td>257</td><td>Revista Colombiana de Ciencias Quimico - Farmaceuticas</td><td><a href=http://revistas.unal.edu.co/index.php/rccquifa target='_blank'>http://revistas.unal.edu.co/index.php/rccquifa</td><td>Free site</td><td>Espanol</td></tr><tr><td>258</td><td>Revista de la OFIL</td><td><a href=http://www.revistadelaofil.org/ target='_blank'>http://www.revistadelaofil.org/</td><td>Free site</td><td>Espanol</td></tr><tr><td>259</td><td>Revista Espanola de Quimioterapia</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3489/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3489/</td><td>Free site</td><td>Espanol/English</td></tr><tr><td>260</td><td>SA Pharmaceutical Journal</td><td><a href=http://www.sapj.co.za/ target='_blank'>http://www.sapj.co.za/</td><td>Free site</td><td>English</td></tr><tr><td>261</td><td>Saudi Pharmaceutical Journal</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2116/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2116/</td><td>Free site</td><td>English</td></tr><tr><td>262</td><td>Scientia Pharmaceutica</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1378/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1378/</td><td>Free site</td><td>English</td></tr><tr><td>263</td><td>Signal Transduction and Targeted Therapy</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/3308/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/3308/</td><td>Free site</td><td>English</td></tr><tr><td>264</td><td>Therapeutic Advances in Chronic Disease</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/1952/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/1952/</td><td>Free site</td><td>English</td></tr><tr><td>265</td><td>Therapeutic Advances in Drug Safety</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/2535/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/2535/</td><td>Free site</td><td>English</td></tr><tr><td>266</td><td>Therapeutics and Clinical Risk Management</td><td><a href=https://www.ncbi.nlm.nih.gov/pmc/journals/370/ target='_blank'>https://www.ncbi.nlm.nih.gov/pmc/journals/370/</td><td>Free site</td><td>English</td></tr><tr><td>267</td><td>Therapeutics Letter</td><td><a href=http://www.ti.ubc.ca/therapeutics-letter/ target='_blank'>http://www.ti.ubc.ca/therapeutics-letter/</td><td>Free site</td><td>English</td></tr><tr><td>268</td><td>Trends in Pharmaceutical Sciences</td><td><a href=http://tips.sums.ac.ir/index.php/TiPS/index target='_blank'>http://tips.sums.ac.ir/index.php/TiPS/index</td><td>Free site</td><td>English</td></tr><tr><td>269</td><td>Turkish Journal of Pharmaceutical Sciences</td><td><a href=http://www.turkjps.org/ target='_blank'>http://www.turkjps.org/</td><td>Free site</td><td>English</td></tr><tr><td>270</td><td>U.S. Pharmacist</td><td><a href=http://www.uspharmacist.com/ target='_blank'>http://www.uspharmacist.com/</td><td>Free site</td><td>English</td></tr><tr><td>271</td><td>UK Journal of Pharmaceutical and Biosciences</td><td><a href=http://www.ukjpb.com/ target='_blank'>http://www.ukjpb.com/</td><td>Free site</td><td>English</td></tr><tr><td>272</td><td>Universal Journal of Pharmaceutical Research</td><td><a href=http://www.ujpr.org/ target='_blank'>http://www.ujpr.org/</td><td>Free site</td><td>English</td></tr><tr><td>273</td><td>WHO Drug Information</td><td><a href=http://www.who.int/medicines/publications/druginformation/en/ target='_blank'>http://www.who.int/medicines/publications/druginformation/en/</td><td>Free site</td><td>English</td></tr><tr><td>274</td><td>WHO Pharmaceuticals Newsletter</td><td><a href=http://www.who.int/medicines/publications/newsletter/en/ target='_blank'>http://www.who.int/medicines/publications/newsletter/en/</td><td>Free site</td><td>English</td></tr><tr><td>275</td><td>World Journal of Pharmaceutical Sciences</td><td><a href=http://www.wjpsonline.org/ target='_blank'>http://www.wjpsonline.org/</td><td>Free site</td><td>English</td></tr><tr><td>276</td><td>World Journal of Pharmacy and Pharmaceutical Sciences</td><td><a href=http://www.wjpr.net/ target='_blank'>http://www.wjpr.net/</td><td>Free site</td><td>English</td></tr><tbody></table>
          </div>
          <div class="col-md-3">
		  
		  <!-- Left Menu-->
		 <div class="sidebar sidebar-left mt-sm-30">
              <div class="widget">
                <h5 class="widget-title line-bottom">Library</h5>
				<!--<ul class="list list-divider list-border">  
				 <li><a href="library.php?pageid=31&DMCG+Library"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> DMCG Library</a></li>
		<li><a href="library.php?pageid=46&Online Catalogue"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> Online Catalogue</a></li>
		<li><a href="library.php?pageid=47&E-Books"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> E-Books</a></li>
		<li><a href="library.php?pageid=48&Databases"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> Databases</a></li>
		<li><strong><i class="fa fa-bookmark-o mr-10 text-black-light"></i> E-Journals</strong></li></ul>
		<ul class="list-border list-pd10s">
		<li><a href="journals1.php">Medline Complete</a></li>
		<li><a href="journals3.php">Open Access Journals</a></li>
		<li><a href="library.php?pageid=49&Other+Journals">Other Journals </a></li>
		</ul>-->
		<ul class="list list-divider list-border">  
				 <li><a href="library.php?pageid=31&DMCGLibrary"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> DMCG Library</a></li> 
		<li><a href="library.php?pageid=47&EResources"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> E-Resources</a></li> 
		<li><strong><i class="fa fa-bookmark-o mr-10 text-black-light"></i> E-Journals</strong></li></ul>
		<ul class="list-border list-pd10s">
		<li><a href="journals1.php">Medline Complete</a></li>
		<li><a href="journals3.php">Open Access Journals</a></li>
		<li><a href="library.php?pageid=49&Other+Journals">Other Journals </a></li>
		</ul>              </div>
               <!-- banner here-->
                
            </div>
            <!-- End Menu-->
          </div>
        </div> 
		
      </div>
    </section>
  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
  <footer id="footer" class="footer fixed-footer" data-bg-color="#212331">
    <div class="container pt-40 pb-10">
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-5 mb-20" alt="" src="images/logo-white-footer.png">
            <p>Muhaisanah 1, Al Mizhar, Dubai.</p>
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">9714-2120555</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored2 mr-5"></i> <a class="text-gray" href="#"> dmcg@dmcg.edu</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">www.dmcg.edu</a> </li>
            </ul>            
            <ul class="styled-icons icon-sm icon-bordered icon-circled clearfix mt-10">
              <li><a href="https://www.facebook.com/dmcg.edu" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/dmc_edu" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/school/dubai-medical-college" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.instagram.com/dubaimedicalcollegeforgirls/" target="_blank"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Useful Links</h4>
            <ul class="angle-double-right list-border">
              <li><a href="academics.php?pageid=21&ProgramDetails">MBBCH Program</a></li>
              <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>
              <li><a href="main.php?pageid=12&VisionMission">Vision & Mission</a></li>
              <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li> 
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
		    <h4 class="widget-title line-bottom-theme-colored-2">Jobs Vacancies</h4>
            <div class="latest-posts">
			  


              <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Student Counsellor</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Career Guidance & Alumni Affairs</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			    
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Opening Hours</h4>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span> Mon - Thu :  </span>
                  <div class="value pull-right"> 7.30 AM to 3.30 PM </div>
                </li>
                <li class="clearfix"> <span> Fri :</span>
                  <div class="value pull-right"> 7.30 AM to 12.00 Noon </div>
                </li> 
                <li class="clearfix"> <span> Sat -Sun : </span>
                  <div class="value pull-right bg-theme-colored2 text-white closed"> Closed </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
	


    <div class="footer-bottom" data-bg-color="#2b2d3b">
      <div class="container pt-5 pb-10">
        <div class="row">
          <div class="col-md-6">
            <p class="font-12 text-black-777 m-0 sm-text-center">Copyright &copy; DMCG. All Rights Reserved. Website updated 13/11/2022</p>
          </div>
          <div class="col-md-6 text-right">
            <div class="widget no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12">
                <li>
                  <a href="#">Terms & Conditions</a>
                </li>
                <li>|</li>
                <li>
                  <a href="dmcg.php?pageid=86&Privacy Policy">Privacy Policy</a>
                </li> 
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>
	<!-- Bootstrap Data Table Plugin -->
	<script src="js/components/bs-datatable.js"></script>
	
 <input type="hidden" name="ids" id="ids" value="1" readonly />
<script type="text/javascript">
var chatinput = document.getElementById("ids").value;
if (chatinput == "" || chatinput.length == 0 || chatinput == null)
{
    window.location = "index.php";
}
</script>
<script>

		$(document).ready(function() {
			$('#datatable1').dataTable( {
        "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]]
    });
		});

	</script>
</body>
</html>