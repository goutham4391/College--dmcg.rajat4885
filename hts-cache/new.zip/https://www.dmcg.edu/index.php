<!DOCTYPE html>

<html dir="ltr" lang="en">

<head>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-86S09WJT92"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-86S09WJT92');
</script>





<!-- Meta Tags -->

<meta name="viewport" content="width=device-width,initial-scale=1.0"/>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>

<meta name="description" content="Dubai Medical College for Girls is the first college to award a degree in medicine & surgery in the UAE  " />
<meta name="keywords" content=" Bachelor in Medicine, Surgery, MBBCh, First Medical College in UAE,  MBBS, education,university,educational,learn,Dubai Medical College for Girls, Dubai, UAE, teaching,medical education, Professional Practice, Clinical, Biomedical Science,  Clinical Science, Health and Behavioral Sciences, Islamic values, research" />
<meta name="author" content="Dubai Medical College for Girls' IT Department" />



<!-- Page Title -->

<title>Welcome to Dubai Medical College for Girls </title>





<!-- Favicon and Touch Icons -->

<link href="images/favicon.png" rel="shortcut icon" type="image/png">

<link href="images/apple-touch-icon.png" rel="apple-touch-icon">

<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">

<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">

<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">



<!-- Stylesheet -->

<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">

<link href="css/animate.css" rel="stylesheet" type="text/css">

<link href="css/css-plugin-collections.css" rel="stylesheet"/>

<!-- CSS | menuzord megamenu skins -->

<link href="css/menuzord-megamenu.css" rel="stylesheet"/>

<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>

<!-- CSS | Main style file -->

<link href="css/style-main.css" rel="stylesheet" type="text/css">

<!-- CSS | Preloader Styles -->

 <link href="css/preloader.css" rel="stylesheet" type="text/css"> 

<!-- CSS | Custom Margin Padding Collection -->

<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">

<!-- CSS | Responsive media queries -->

<link href="css/responsive.css" rel="stylesheet" type="text/css">

<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->

<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->



<!-- Revolution Slider 5.x CSS settings -->

<link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>

<link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>

<link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>



<!-- CSS | Theme Color -->

<link href="css/colors/theme-skin-color-set3.css" rel="stylesheet" type="text/css">



<script src="js/jquery-2.2.4.min.js"></script>

<script src="js/jquery-ui.min.js"></script>

<script src="js/bootstrap.min.js"></script>

<!-- JS | jquery plugin collection for this theme -->

<script src="js/jquery-plugin-collection.js"></script>



<!-- Revolution Slider 5.x SCRIPTS -->

<script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>

<script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>



<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

<!--[if lt IE 9]>

  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

<![endif]-->

</head>

<body class="has-fixed-footer">

<div id="wrapper" class="clearfix">

  <!-- preloader -->

  <div id="preloader">

    <div id="spinner">

      <img alt="" src="images/preloaders/1.gif">

    </div>

    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>

  </div> 

  

  <!-- Header --> 

         <header id="header" class="header header-floating">

  <div class="header-top bg-theme-colored2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="widget text-white">
              <ul class="list-inline xs-text-center text-white">
                <li class="m-0 pl-10 pr-10"> <a href="#" class="text-white"><i class="fa fa-phone text-white"></i>+9714-2120555</a> </li>
                <li class="m-0 pl-10 pr-10"> 
                  <a href="#" class="text-white"><i class="fa fa-envelope-o text-white mr-5"></i> dmcg@dmcg.edu</a> 
                </li>
              </ul>
            </div>
          </div> 
          <div class="col-md-6">
            <ul class="list-inline sm-pull-none sm-text-center text-right text-white mb-sm-20 mt-10">
			<li> <a href="jobs.php" class="text-white">Careers</a> | </li>
			<li> <a href="https://dmcg.edu/helpdesk/" target="_blank"  class="text-white"> IT Helpdesk</a> | </li>
			<li class="dropdown">
                  <a href="#" class="dropdown-toggle text-white" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Campus Logins <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="https://dmug.brightspace.com/d2l/login" target="_blank"><i class="fa fa-graduation-cap mr-5"></i> LMS Login</a></li>
                    <!--<li><a href="#"><i class="fa fa-edit mr-5"></i> SIS Login</a></a></li>-->
                    <li><a href="https://www.office.com/?auth=2" target="_blank"><i class="fa fa-envelope mr-5"></i> Office 365</a></li> 
                    
                  </ul>
                </li>             
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="header-nav navbar-sticky navbar-sticky-animated">

      <div class="header-nav-wrapper">

        <div class="container">

        <nav id="menuzord-right" class="menuzord default no-bg">

            <a class="menuzord-brand switchable-logo pull-left flip mb-15" href="index.php">

              <img class="logo-default" src="images/logo-dmc_white.png" alt="">

              <img class="logo-scrolled-to-fixed" src="images/logo-dmc.png" alt="">

            </a>

            <ul class="menuzord-menu">
              <li class="active"><a href="index.php">Home</a> 
              </li>
              <li><a href="#">About Us </a>
                <ul class="dropdown"> 
                <li><a href="main.php?pageid=74&AboutDmcg">About DMCG</a></li>
                <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>				
				 <li><a href="main.php?pageid=13&DeansMessage">Dean's Message</a></li>
				 <li><a href="main.php?pageid=17&BoardTrustees">Board of Trustees</a></li>		 
				 <li><a href="main.php?pageid=73&Leadership">DMCG Leadership</a></li>
                 <li><a href="main.php?pageid=12&VisionMission">The Vision &amp; Mission</a></li>
				 <li><a href="main.php?pageid=16&GoalsObjectives">Goals and Objectives</a></li>	
				 <li><a href="main.php?pageid=15&CollegePublications">College Publications</a></li>
				 <li><a href="main.php?pageid=18&OrganizationStructure">Organization Structure</a></li>			 
				 <li><a href="main.php?pageid=14&AboutDubai">About Dubai</a></li>
                </ul>
              </li>
              <li><a href="#">Academics</a>
                <ul class="dropdown">
                  <li><a href="academics.php?pageid=22&ProgramLearning">MBBCH</a>
                    <ul class="dropdown">
					  <li><a href="#">Calendars</a>
					   <ul class="dropdown">
					   <li><a href="academics.php?pageid=19&AcademicCalendar">Academic Calendar</a></li>
                      <li><a href="academics.php?pageid=20&EventsCalendar">Events Calendar</a></li>
					  <li><a href="academics.php?pageid=85&ExaminationCalendar">Examination Calendar</a></li></ul>
					  </li> 
					  <!--<li><a href="academics.php?pageid=21&ProgramDetails">Program Details</a></li>-->
					  <li><a href="academics.php?pageid=22&ProgramLearning">Program Learning Outcomes</a></li>
					  <li><a href="academics.php?pageid=23&TeachingPlan">Teaching Plan</a></li>
					  <li><a href="academics.php?pageid=24&CourseDescription">Course Description</a></li>
					  <li><a href="academics.php?pageid=79&Timetables">Timetables</a></li>
					  <li><a href="academics.php?pageid=84&CourseCatalogue">Course Catalogue</a></li>
					  <li><a href="academics.php?pageid=87&StudyGuide">Study Guide</a></li>
					  <li><a href="academics.php?pageid=81&GraduationCriteria">Graduation Criteria</a></li>
					  <li><a href="academics.php?pageid=82&AcademicFaculty">Academic Faculty & Staff</a></li>
					  <li><a href="academics.php?pageid=83&AdjunctFaculty">Adjunct Faculty Manual</a></li>
                    </ul>
                  </li>                  
                </ul>
              </li> 
              <li><a href="#">Life At Campus</a>
                <ul class="dropdown">  
                  <li><a href="campus.php?pageid=51&Departments">Departments</a></li>
				  <li><a href="campus.php?pageid=75&StudentAffairs">Student Affairs</a>
                    <ul class="dropdown">                      
				    <li><a href="campus.php?pageid=36&CareerGuidance">Career Guidance</a></li> 
				 	<li><a href="campus.php?pageid=35&StudentCounselling">Student Counselling</a></li> 
				 	<li><a href="campus.php?pageid=76&StudentServices">Student Support Services</a></li> 
				 	<li><a href="campus.php?pageid=34&Hostel">Hostel Facilities</a></li> 			  
                    </ul>
                  </li>				   
				  <li><a href="campus.php?pageid=80&SimulationCenter">Simulation Center</a></li>
				  <li><a href="campus.php?pageid=32&LearningCenter">Learning Center</a></li>
                  <li><a href="campus.php?pageid=33&FacilitiesDHA">Facilities at DHA</a></li>
				<li><a href="campus.php?pageid=78&TeachingFacilities">Teaching Facilities</a></li>
                </ul> 
              </li>
			  <li><a href="#">Research</a>
                <ul class="dropdown"> 
				 <!--<li><a href="research.php?pageid=37&Director+of+Research">Director of Research</a></li>--> 
				 <li><a href="research.php?pageid=38&AimofResearch">Aim of Research at DMCG</a></li>
				 <li><a href="research.php?pageid=39&ResearchCollaborations">Research Collaborations</a></li>
				 <li><a href="research.php?pageid=40&ResearchSupport">Research Support</a></li>
				 <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li>
				 <li><a href="research.php?pageid=42&Publications">DMCG Academic Publications</a></li>
				 <li><a href="research.php?pageid=45&Researchpolicy">Research Policy</a></li>
                </ul>
              </li>
			  <li><a href="#">Library</a>
                <ul class="dropdown">  
                  <li><a href="library.php?pageid=31&DMCGLibrary">DMCG Library</a></li>
				  <li><a href="library.php?pageid=47&EResources">E-Resources</a></li>
				  <li><a href="#">E-Journals</a>
				   <ul class="dropdown">
                      <li><a href="journals1.php">Medline Complete</a></li> 
					  <li><a href="journals3.php">Open Access Journals </a></li>
					  <li><a href="library.php?pageid=49&OtherJournals">Other Journals </a></li>
                    </ul></li>
                </ul> 
              </li>
			  <li><a href="#">Media</a>
                <ul class="dropdown"> 
                  <li><a href="announcements.php">Announcements</a></li>
                  <!--<li><a href="media.php?nncategory_id=1&News">News</a></li>-->
                  <li><a href="event.php?ecategory_id=1&DMCG Events">Events</a></li>
				 <li><a href="collegem.php">College Magazines</a></li> 
				 <li><a href="event.php?ecategory_id=2&DMCG Updates">DMCG Updates</a></li> 
                </ul>
              </li>
			  <li><a href="contact.php">Contact</a>               
              </li>
            </ul>

		
          </nav>

		  </div>

      </div>

    </div>

  </header> 

  

  <!-- Start main-content -->

  <div class="main-content">

    <!-- Section: home -->

    <section id="home">

      <div class="container-fluid p-0">

        

        <!-- START REVOLUTION SLIDER 5.0.7 -->

        <div id="rev_slider_home_wrapper" class="rev_slider_wrapper" data-alias="news-gallery34" style="margin:0px auto; background-color:#ffffff; padding:0px; margin-top:0px; margin-bottom:0px;">

               <div id="rev_slider_home" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.0.7">

            <ul>

			<li data-index="rs-8" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/dmcg_cleanday_sl.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/recre_sl.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
 

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-8-layer-1" 

                  data-x="['center','center','center','center']" data-hoffset="['190','0','0','0']" 

                    data-y="['top','top','top','top']" data-voffset="['320','210','250','50']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"> <a class="btn btn-dark  btn-transparent btn-bordered btn-lg btn-flat font-weight-600 pl-30 pr-30" href="https://www.dmcg.edu/events.php?id=50">Read More</a>

                </div>

              </li>
			   <li data-index="rs-7" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/essad2022.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/dmcg_cleanday_sl.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
 

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-7-layer-4" 

                  data-x="['center','center','center','center']" data-hoffset="['-190','0','0','0']" 

                    data-y="['top','top','top','top']" data-voffset="['320','210','250','50']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"> <a class="btn btn-dark  btn-transparent btn-bordered btn-lg btn-flat font-weight-600 pl-30 pr-30" href="https://www.dmcg.edu/events.php?id=49">Read More</a>

                </div>

              </li>
			<li data-index="rs-6" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/essad2022.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/flagday_sl.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
 

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-6-layer-4" 

                  data-x="['center','center','center','center']" data-hoffset="['-190','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['480','320','320','280']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"> <a class="btn btn-dark  btn-transparent btn-bordered btn-lg btn-flat font-weight-600 pl-30 pr-30" href="https://www.dmcg.edu/events.php?id=47">Read More</a>

                </div>

              </li>
			  <li data-index="rs-5" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/Interuniversity_sl.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/essad2022.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>

                <!-- LAYERS --> 

                 

                <!-- LAYER NR. 4 -->

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-5-layer-1" 

                  data-x="['center','center','center','center']" data-hoffset="['-150','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['300','210','220','90']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:200;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"> <a class="btn btn-dark  btn-transparent btn-bordered btn-lg btn-flat font-weight-600 pl-30 pr-30" href="https://www.dmcg.edu/events.php?id=48">Read More</a> 

                </div>

              </li>
			  <li data-index="rs-4" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/etuesday2022.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/Interuniversity_sl.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>

                <!-- LAYERS --> 

                 

                <!-- LAYER NR. 4 -->

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-4-layer-1" 

                  data-x="['center','center','center','center']" data-hoffset="['-30','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['230','210','290','90']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:200;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"> <a class="btn btn-dark  btn-transparent btn-bordered btn-lg btn-flat font-weight-600 pl-30 pr-30" href="https://www.dmcg.edu/events.php?id=46">Read More</a>

                </div>

              </li> 
			  
			  <li data-index="rs-3" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/etuesday2022.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/etuesday2022.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>

                <!-- LAYERS -->

                <!-- LAYER NR. 1 -->

                

                <!-- LAYER NR. 2 -->

                <div class="tp-caption tp-resizeme rs-parallaxlevel-0 text-white  font-roboto-slab font-weight-700" 

                  id="slide-3-layer-2" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['195','195','160','170']" 

                  data-fontsize="['48','38','32','26']"

                  data-lineheight="['70','60','50','45']"

                  data-fontweight="['800','700','700','700']"

                  data-textalign="['center','center','center','center']"

                  data-width="['700','650','600','420']"

                  data-height="none"

                  data-whitespace="normal"

                  data-transform_idle="o:1;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 

                  data-mask_out="x:0;y:0;s:inherit;e:inherit;" 

                  data-start="600" 

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  style="z-index: 5; white-space: nowrap; font-weight:500;">&nbsp;

                </div>

                <!-- LAYER NR. 3 -->

                <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" 

                  id="slide-3-layer-3" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['325','310','270','270']"

                  data-fontsize="['16','16',18',16']"

                  data-lineheight="['24','24','24','24']"

                  data-fontweight="['400','400','400','400']"

                  data-textalign="['center','center','center','center']"

                  data-width="['800','650','600','460']"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 

                  data-mask_out="x:0;y:0;s:inherit;e:inherit;" 

                  data-start="700" 

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  style="z-index: 5; white-space: nowrap;"><span class="text-theme-colored2">&nbsp; </span>  

                </div>

                <!-- LAYER NR. 4 -->

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-3-layer-4" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['350','330','290','290']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"> <a class="btn btn-default  btn-transparent btn-bordered btn-lg btn-flat font-weight-600 pl-30 pr-30" href="https://www.dmcg.edu/events.php?id=42&e-Tuesdays&1">Read More</a>

                </div>

              </li> 
			<!-- SLIDE 1 -->

              
			  <li data-index="rs-2" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/slider1.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/slider4.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>

                <!-- LAYERS -->

                <!-- LAYER NR. 1 -->

                <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0 bg-theme-colored-transparent-4" 

                  id="slide-2-layer-1" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                  data-width="full"

                  data-height="full"

                  data-whitespace="normal"

                  data-transform_idle="o:1;"

                  data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 

                  data-start="500" 

                  data-basealign="slide" 

                  data-responsive_offset="on" 

                  style="z-index: 5;background-color:rgba(0, 0, 0, 0.35);border-color:rgba(0, 0, 0, 1.00);"> 

                </div>

                <!-- LAYER NR. 2 -->

                <div class="tp-caption tp-resizeme rs-parallaxlevel-0 text-white  font-roboto-slab font-weight-700" 

                  id="slide-2-layer-2" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['195','195','160','170']" 

                  data-fontsize="['48','38','32','26']"

                  data-lineheight="['70','60','50','45']"

                  data-fontweight="['800','700','700','700']"

                  data-textalign="['center','center','center','center']"

                  data-width="['700','650','600','420']"

                  data-height="none"

                  data-whitespace="normal"

                  data-transform_idle="o:1;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 

                  data-mask_out="x:0;y:0;s:inherit;e:inherit;" 

                  data-start="600" 

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  style="z-index: 5; white-space: nowrap; font-weight:500;">UAE's 1st Private Medical <span class="text-theme-colored2"> College</span> 

                </div>

                <!-- LAYER NR. 3 -->

                <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" 

                  id="slide-2-layer-3" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['325','310','270','270']"

                  data-fontsize="['16','16',18',16']"

                  data-lineheight="['24','24','24','24']"

                  data-fontweight="['400','400','400','400']"

                  data-textalign="['center','center','center','center']"

                  data-width="['800','650','600','460']"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 

                  data-mask_out="x:0;y:0;s:inherit;e:inherit;" 

                  data-start="700" 

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  style="z-index: 5; white-space: nowrap;"><span class="text-theme-colored2">Awarded </span> degree in medicine & surgery 

                </div>

                <!-- LAYER NR. 4 -->

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-2-layer-4" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['350','330','290','290']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"> <a class="btn btn-default btn-transparent btn-bordered btn-lg btn-flat font-weight-600 pl-30 pr-30" href="news.php?id=2">Know More</a>

                </div>

              </li>

			<!-- SLIDE 1 -->

              

              <!-- SLIDE 3 -->

              <li data-index="rs-1" data-transition="fade" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/bg/slider5.jpg" data-rotate="0"  data-fstransition="fade" data-saveperformance="off" data-title="Web Show" data-description="">

                <!-- MAIN IMAGE -->

                <img src="images/bg/slider6.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>

                <!-- LAYERS -->

                <!-- LAYER NR. 1 -->

                <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0 bg-theme-colored-transparent-4" 

                  id="slide-1-layer-1" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                  data-width="full"

                  data-height="full"

                  data-whitespace="normal"

                  data-transform_idle="o:1;"

                  data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 

                  data-start="500" 

                  data-basealign="slide" 

                  data-responsive_offset="on" 

                  style="z-index: 5;background-color:rgba(0, 0, 0, 0.35);border-color:rgba(0, 0, 0, 1.00);"> 

                </div>

                <!-- LAYER NR. 2 -->

                <div class="tp-caption tp-resizeme rs-parallaxlevel-0 text-white text-uppercase font-roboto-slab font-weight-700" 

                  id="slide-1-layer-2" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['195','195','160','170']" 

                  data-fontsize="['58','48','42','36']"

                  data-lineheight="['70','60','50','45']"

                  data-fontweight="['800','700','700','700']"

                  data-textalign="['center','center','center','center']"

                  data-width="['700','650','600','420']"

                  data-height="none"

                  data-whitespace="normal"

                  data-transform_idle="o:1;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 

                  data-mask_out="x:0;y:0;s:inherit;e:inherit;" 

                  data-start="600" 

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  style="z-index: 5; white-space: nowrap; font-weight:700;">Gateway to <span class="text-theme-colored2"> Future</span>

                </div>

                <!-- LAYER NR. 3 -->

                <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" 

                  id="slide-1-layer-3" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['275','260','220','220']"

                  data-fontsize="['16','16',18',16']"

                  data-lineheight="['24','24','24','24']"

                  data-fontweight="['400','400','400','400']"

                  data-textalign="['center','center','center','center']"

                  data-width="['800','650','600','460']"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 

                  data-mask_out="x:0;y:0;s:inherit;e:inherit;" 

                  data-start="700" 

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  style="z-index: 5; white-space: nowrap;">we always provide the best educational services to all our students <br> and always try to achieve the trust and satisfaction of our students

                </div>

                <!-- LAYER NR. 4 -->

                <div class="tp-caption rs-parallaxlevel-0" 

                  id="slide-1-layer-4" 

                  data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                  data-y="['top','top','top','top']" data-voffset="['350','330','290','290']" 

                  data-width="none"

                  data-height="none"

                  data-whitespace="nowrap"

                  data-transform_idle="o:1;"

                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"

                  data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" 

                  data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" 

                  data-mask_in="x:0px;y:0px;" 

                  data-mask_out="x:0;y:0;" 

                  data-start="800"

                  data-splitin="none" 

                  data-splitout="none" 

                  data-responsive_offset="on" 

                  data-responsive="off"

                  style="z-index: 5; white-space: nowrap; letter-spacing:1px;"><a class="btn btn-theme-colored2 btn-lg btn-flat text-white font-weight-600 pl-30 pr-30 mr-15" href="academics.php?pageid=21&Program+Details">Know More</a>

                </div>

              </li>

            </ul>

            <div class="tp-bannertimer tp-bottom" style="height: 5px; background-color: rgba(255, 255, 255, 0.2);"></div>

          </div>
        </div>



        <!-- END REVOLUTION SLIDER -->

        <script type="text/javascript">

          var tpj=jQuery;

          var revapi34;

          tpj(document).ready(function() {

            if(tpj("#rev_slider_home").revolution == undefined){

              revslider_showDoubleJqueryError("#rev_slider_home");

            }else{

              revapi34 = tpj("#rev_slider_home").show().revolution({

                sliderType:"standard",

                jsFileLocation:"js/revolution-slider/js/",

                sliderLayout:"fullscreen",

                dottedOverlay:"none",

                delay:3000,

                navigation: {

                  keyboardNavigation:"on",

                  keyboard_direction: "horizontal",

                  mouseScrollNavigation:"off",

                  onHoverStop:"on",

                  touch:{

                    touchenabled:"on",

                    swipe_threshold: 75,

                    swipe_min_touches: 1,

                    swipe_direction: "horizontal",

                    drag_block_vertical: false

                  }

                  ,

                  arrows: {

                    style:"zeus",

                    enable:true,

                    hide_onmobile:true,

                    hide_under:600,

                    hide_onleave:true,

                    hide_delay:200,

                    hide_delay_mobile:1200,

                    tmp:'<div class="tp-title-wrap">    <div class="tp-arr-imgholder"></div> </div>',

                    left: {

                      h_align:"left",

                      v_align:"center",

                      h_offset:30,

                      v_offset:0

                    },

                    right: {

                      h_align:"right",

                      v_align:"center",

                      h_offset:30,

                      v_offset:0

                    }

                  },

                  bullets: {

                    enable:false,

                    hide_onmobile:true,

                    hide_under:600,

                    style:"metis",

                    hide_onleave:true,

                    hide_delay:200,

                    hide_delay_mobile:1200,

                    direction:"horizontal",

                    h_align:"center",

                    v_align:"bottom",

                    h_offset:0,

                    v_offset:30,

                    space:5,

                    tmp:'<span class="tp-bullet-img-wrap"><span class="tp-bullet-image"></span></span>'

                  }

                },

                viewPort: {

                  enable:true,

                  outof:"pause",

                  visible_area:"80%"

                },

                responsiveLevels:[1240,1024,778,480],

                gridwidth:[1240,1024,778,480],

                gridheight:[600,550,500,450],

                lazyType:"none",

                parallax: {

                  type:"scroll",

                  origo:"enterpoint",

                  speed:400,

                  levels:[5,10,15,20,25,30,35,40,45,50],

                },

                shadow:0,

                spinner:"off",

                stopLoop:"off",

                stopAfterLoops:-1,

                stopAtSlide:-1,

                shuffle:"off",

                autoHeight:"off",

                hideThumbsOnMobile:"off",

                hideSliderAtLimit:0,

                hideCaptionAtLimit:0,

                hideAllCaptionAtLilmit:0,

                debugMode:false,

                fallbacks: {

                  simplifyAll:"off",

                  nextSlideOnWindowFocus:"off",

                  disableFocusListener:false,

                }

              });

            }

          }); /*ready*/

        </script>

      <!-- END REVOLUTION SLIDER -->



      </div>

    </section>



    <!-- Section: home-boxes -->

    <section>

      <div class="container pt-0 pb-0">

        <div class="section-content">

          <div class="row equal-height-inner home-boxes" data-margin-top="-100px">

            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay1">

              <div class="sm-height-auto" data-bg-color="#5D9CEC">

                <div class="features-box-colored text-center p-15 pt-30 pb-20">

                  <i class="fa fa-graduation-cap font-54 mb-20 text-white"></i>

                  <h4 class="text-uppercase font-weight-600 mt-0"><a href="main.php?pageid=15&College+Publication" class="text-white">DMCG Catalog</a></h4>

                  <p class="text-white">DMCG Catalog contains information about academic programs, student services, general regulations, requirements and procedures</p>

                  <div class="shadow-icon"><i class="pe-7s-study"></i></div>

                </div>

              </div>

            </div>

            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay2">

              <div class="sm-height-auto" data-bg-color="#EF5861">

                <div class="features-box-colored text-center p-15 pt-30 pb-20">

                  <i class="fa fa-book font-54 mb-20 text-white"></i>

                  <h4 class="text-uppercase font-weight-600 mt-0"><a href="#" class="text-white">Modern Library</a></h4>

                  <p class="text-white">Our central library is deigned to house a vast collection of books, journals, audiovisuals and subscribed e -Journals. </p>

                  <div class="shadow-icon"><i class="pe-7s-notebook"></i></div>

                </div>

              </div>

            </div>

            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay3">

              <div class="sm-height-auto" data-bg-color="#E79800">

                <div class="features-box-colored text-center p-15 pt-30 pb-20">

                  <i class="fa fa-flask font-54 mb-20 text-white"></i>

                  <h4 class="text-uppercase font-weight-600 mt-0"><a href="research.php?pageid=38&Aim+of+Research+at+DMCG" class="text-white">Research</a></h4>

                  <p class="text-white">Enhance research excellence, expressed in the production of quality, high impact and citation research articles and oral presentations</p>

                  <div class="shadow-icon"><i class="pe-7s-science"></i></div>

                </div>

              </div>

            </div>

            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay4">

              <div class="sm-height-auto" data-bg-color="#43B14B">

                <div class="features-box-colored text-center p-15 pt-30 pb-20">

                  <i class="fa fa-cubes font-54 mb-20 text-white"></i>

                  <h4 class="text-uppercase font-weight-600 mt-0"><a href="campus.php?pageid=51&Departments" class="text-white">Departments</a></h4>

                  <p class="text-white">DMCG provides the students with the necessary information required teaching the basic properties of the organisms</p>

                  <div class="shadow-icon"><i class="pe-7s-notebook"></i></div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

    </section>



    <!-- Section About -->

    <section>

      <div class="container pt-50 pb-30">

        <div class="section-title">

          <div class="row">

            <div class="col-sm-12 col-md-8">

              <h3 class="text-uppercase font-weight-600 mt-0">Welcome to Dubai Medical College for Girls</h3>

              <div class="double-line-bottom-theme-colored-2"></div>

              <p class="font-16 mt-20">Dubai Medical College for Girls (DMCG) is committed to providing students with medical education to obtain an accredited degree of Bachelor in Medicine and Surgery in the UAE. The college will achieve its mission by providing a learning environment, both inside and outside the classroom that sustains Islamic values and promotes high levels of student achievement, consistent with the highest standards of academic excellence.</p>

              <a href="main.php?pageid=11&Founders+Message" class="btn btn-colored btn-theme-colored2 text-white btn-lg pl-40 pr-40 mt-10">Read More</a>

            <table width="100%" border="0" cellspacing="5" cellpadding="10" style="margin-top:15px;">

  <tr>

    <td><a href="https://dmug.brightspace.com/d2l/login" target="_blank"><img class="img-absolute-parent" alt="" src="images/lms.png"></a></td>

     <td><a href="https://www.qedex.org/" target="_blank"><img class="img-absolute-parent" alt="" src="images/qdex.jpg"></a></td>

    <td><img class="img-absolute-parent" alt="" src="images/uae_50b.png"></td>

  </tr>

</table>

 

		</div>           

            <div class="col-md-4">

              <h3 class="text-uppercase font-weight-600 mt-0 mt-sm-30">Latest <span class="text-theme-colored2">Announcements</span></h3>

              <div class="double-line-bottom-theme-colored-2"></div>

			  


<article>
                <div class="event-small media sm-maxwidth400 mt-0 mb-0 pt-0 pb-15">
                  <div class="event-date text-center">
                    <ul class="text-white">
                      <li class="font-18 font-weight-700 border-bottom">03</li>
                      <li class="font-14 text-center text-uppercase mt-5">Nov</li>
                    </ul>
                  </div>
                  <div class="event-content pt-5">
                    <h5 class="media-heading font-14 font-weight-600 mb-5"><a href="announcement.php?id=12&1st Annual Students Research and Scientific Day">1st Annual Students Research and Scientific Day</a></h5>
                    
                  </div>
                </div>
              </article>
			  <article>
                <div class="event-small media sm-maxwidth400 mt-0 mb-0 pt-0 pb-15">
                  <div class="event-date text-center">
                    <ul class="text-white">
                      <li class="font-18 font-weight-700 border-bottom">27</li>
                      <li class="font-14 text-center text-uppercase mt-5">Oct</li>
                    </ul>
                  </div>
                  <div class="event-content pt-5">
                    <h5 class="media-heading font-14 font-weight-600 mb-5"><a href="announcement.php?id=11&Final Exam Schedule of Biomedical Sciences Third Year Batch (35 ) AY 2022-2023">Final Exam Schedule of Biomedical Sciences Third Year Batch (35 ) AY 2022-2023</a></h5>
                    
                  </div>
                </div>
              </article>
			  <article>
                <div class="event-small media sm-maxwidth400 mt-0 mb-0 pt-0 pb-15">
                  <div class="event-date text-center">
                    <ul class="text-white">
                      <li class="font-18 font-weight-700 border-bottom">25</li>
                      <li class="font-14 text-center text-uppercase mt-5">Oct</li>
                    </ul>
                  </div>
                  <div class="event-content pt-5">
                    <h5 class="media-heading font-14 font-weight-600 mb-5"><a href="announcement.php?id=10&Exam Schedule of Clinical Sciences Academic Year 2022-2023">Exam Schedule of Clinical Sciences Academic Year 2022-2023</a></h5>
                    
                  </div>
                </div>
              </article>
			   
              

            </div>

          </div>

        </div>

      </div>

    </section>



    



 

 

 <!-- Section: Courses -->

    <section id="courses" class="bg-silver-deep">

      <div class="container pb-40">

        <div class="section-title">

          <div class="row">

            <div class="col-md-12 text-center">

              <h2 class="text-uppercase title">Our <span class="text-theme-colored2">Departments</span></h2>

              <div class="double-line-bottom-centered-theme-colored-2 mt-20"></div>  

            </div>

          </div>

        </div>

        <div class="row mtli-row-clearfix">

		

					

          <div class="owl-carousel-3col" data-nav="true">

		  
					

            <div class="item">

              <div class="course-single-item bg-white border-1px clearfix mb-30">

                <div class="course-thumb">

                  <img class="img-fullwidth" alt="" src="images/gallery/bio_dept.jpg"> 

                </div>

                <div class="course-details clearfix p-20 pt-15">

                  <div class="course-top-part pull-left mr-40">

                    <a href="campus.php?pageid=69&Department of Biomedical Sciences"><h4 class="mt-0 mb-5">Department of Biomedical Sciences</h4></a>                    

                  </div>

                  <div class="clearfix"></div>

                  <p class="course-description mt-20"><p class="mb-0">The Department of Biomedical Sciences at the Dubai medical College for Girls was created by combining multiple disciplines of Biomedical sciences</p>                  

                </div>

              </div>

            </div>

			
					

            <div class="item">

              <div class="course-single-item bg-white border-1px clearfix mb-30">

                <div class="course-thumb">

                  <img class="img-fullwidth" alt="" src="images/gallery/clinica_dept.jpg"> 

                </div>

                <div class="course-details clearfix p-20 pt-15">

                  <div class="course-top-part pull-left mr-40">

                    <a href="campus.php?pageid=71&Department of Clinical Sciences"><h4 class="mt-0 mb-5">Department of Clinical Sciences</h4></a>                    

                  </div>

                  <div class="clearfix"></div>

                  <p class="course-description mt-20"><p class="mb-0"></span>The Department of Clinical Sciences at Dubai Medical College for Girls offers high-quality education programs to medical students. <span data-cke-marker="1"></p>                  

                </div>

              </div>

            </div>

			
					

            <div class="item">

              <div class="course-single-item bg-white border-1px clearfix mb-30">

                <div class="course-thumb">

                  <img class="img-fullwidth" alt="" src="images/gallery/health_depta.jpg"> 

                </div>

                <div class="course-details clearfix p-20 pt-15">

                  <div class="course-top-part pull-left mr-40">

                    <a href="campus.php?pageid=72&Department of Public Health and Behavioral Sciences"><h4 class="mt-0 mb-5">Department of Public Health and Behavioral Sciences</h4></a>                    

                  </div>

                  <div class="clearfix"></div>

                  <p class="course-description mt-20"><p class="mb-0">The Department of Public Health and Behavioral Sciences at Dubai Medical College for Girls aims</p>                  

                </div>

              </div>

            </div>

			              

          </div>

        </div>

      </div>

    </section>


<!-- Divider: Testimonials -->

    <section class="parallax Divider layer-overlay overlay-theme-colored-9" data-bg-img="images/bg/bg2.jpg" data-parallax-ratio="0.4">

      <div class="container pt-70 pb-30"> 

        <div class="row">

          

		  <div class="row">

            <div class="col-md-3">

              <div class="icon-box hover-effect border-1px border-radius-10px text-center bg-white p-10 pt-20 pb-10">

                <a href="#" class="icon icon-circled icon-lg" data-bg-color="#FC9928">

                  <i class="icon_mail text-white font-38"></i>

                </a>

                <h5 class="icon-box-title text-uppercase letter-space-1 font-14 mt-15"><a href="https://www.office.com/?auth=2" target="_blank">Email login</a></h5> 

              </div>

            </div>

            <div class="col-md-3">

              <div class="icon-box hover-effect border-1px border-radius-10px text-center bg-white p-10 pt-20 pb-10">

                <a href="#" class="icon icon-circled icon-lg" data-bg-color="#43B14B">

                  <i class="icon_book text-white font-38"></i>

                </a>

                <h4 class="icon-box-title text-uppercase letter-space-1 font-14 mt-15"><a href="library.php?pageid=46&Online%20Catalogue">Online Library</a></h4> 

              </div>

            </div>

            <div class="col-md-3">

              <div class="icon-box hover-effect border-1px border-radius-10px text-center bg-white p-10 pt-20 pb-10">

                <a href="#" class="icon icon-circled icon-lg" data-bg-color="#00C3CB">

                  <i class="icon_headphones text-white font-38"></i>

                </a>

                <h4 class="icon-box-title text-uppercase letter-space-1 font-14 mt-15"><a href="contact.php">Contact us</a></h4> 

              </div>

            </div>

            <div class="col-md-3">

              <div class="icon-box hover-effect border-1px border-radius-10px text-center bg-white p-10 pt-20 pb-10">

                <a href="#" class="icon icon-circled icon-lg" data-bg-color="#EF5861">

                  <i class="icon_link_alt text-white font-38"></i>

                </a>

                <h4 class="icon-box-title text-uppercase letter-space-1 font-14 mt-15"><a href="https://www.qedex.org/" target="_blank">Qedex</a></h4> 

              </div>

            </div>

          </div> 

		  

        </div>

      </div>

    </section>

    <!-- Section About -->

    <section>
      <div class="container pt-30 pb-5">
        <div class="section-title">
          <div class="row">
            <div class="col-sm-12 col-md-6"> 
			<h3 class="text-uppercase font-weight-600 mt-0 mt-sm-30">Latest <span class="text-theme-colored2">News & Events</span></h3>
              <div class="double-line-bottom-theme-colored-2"></div>
              


			  <div class="course-list-block clearfix mb-20">		  
								
                <div class="col-sm-6 col-md-4">
                  <div class="thumb"><a href="events.php?id=51"><img alt="featured project" src="images/gallery/teambase_learnfe.jpg" class="img-fullwidth mt-5"></a></div>
                </div>
                <div class="col-sm-6 col-md-8">
                  <h4 class="line-bottom mt-0 mb-5 mt-sm-20"><a href="events.php?id=51">Faculty Development session</a></h4>
				  <ul  class="mb-6 list-inline">
                              <li><i class="fa fa-calendar mr-5 text-theme-colored2"></i>13th Nov 2022</li>
                              <li><i class="fa fa-bookmark mr-5 text-theme-colored2"></i><a href="event.php?ecategory_id=1&Events">Events</a></li> 
                            </ul>
                  
				<!-- <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="media.php?nncategory_id=1&News"> View All</a>-->
                </div>
              </div>
			  			  <div class="course-list-block clearfix mb-20">		  
								
                <div class="col-sm-6 col-md-4">
                  <div class="thumb"><a href="events.php?id=50"><img alt="featured project" src="images/gallery/recre_fe.jpg" class="img-fullwidth mt-5"></a></div>
                </div>
                <div class="col-sm-6 col-md-8">
                  <h4 class="line-bottom mt-0 mb-5 mt-sm-20"><a href="events.php?id=50">Al Aoun Award Event Hosted by DMCG</a></h4>
				  <ul  class="mb-6 list-inline">
                              <li><i class="fa fa-calendar mr-5 text-theme-colored2"></i>8th Nov 2022</li>
                              <li><i class="fa fa-bookmark mr-5 text-theme-colored2"></i><a href="event.php?ecategory_id=1&Events">Events</a></li> 
                            </ul>
                  
				<!-- <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="media.php?nncategory_id=1&News"> View All</a>-->
                </div>
              </div>
			  			  <div class="course-list-block clearfix mb-20">		  
								
                <div class="col-sm-6 col-md-4">
                  <div class="thumb"><a href="events.php?id=49"><img alt="featured project" src="images/gallery/clean_dae2022fe.jpg" class="img-fullwidth mt-5"></a></div>
                </div>
                <div class="col-sm-6 col-md-8">
                  <h4 class="line-bottom mt-0 mb-5 mt-sm-20"><a href="events.php?id=49">Beach cleaning activity by DMCG with the Emirates Red Crescent</a></h4>
				  <ul  class="mb-6 list-inline">
                              <li><i class="fa fa-calendar mr-5 text-theme-colored2"></i>7th Nov 2022</li>
                              <li><i class="fa fa-bookmark mr-5 text-theme-colored2"></i><a href="event.php?ecategory_id=1&Events">Events</a></li> 
                            </ul>
                  
				<!-- <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="media.php?nncategory_id=1&News"> View All</a>-->
                </div>
              </div>
			   
			  
			  <!--< ?php
					$count=1;
					$sel_query3news="SELECT * FROM nnnews where mnncategory_id='1' AND active='1' order by id desc Limit 1";
								$result3news = mysqli_query($con,$sel_query3news);
								while($rownewse = mysqli_fetch_assoc($result3news))
					{
					?>		
			  
             
           
               <div class="course-list-block clearfix mb-1">
                <div class="col-sm-6 col-md-4"> 
                  <div class="thumb"><a href="news.php?id=< ?php echo $rownewse['id'] ?>"><img alt="featured project" src="< ?php echo $rownewse['image_s']; ?>" class="img-fullwidth mt-5"></a></div>
                </div>
                <div class="col-sm-6 col-md-8">
                  <h4 class="line-bottom mt-0 mb-5 mt-sm-20"><a href="news.php?id=< ?php echo $rownewse['id'] ?>">< ?php echo $rownewse['title'] ?></a></h4>
                  <ul  class="mb-6 list-inline">
                              <li><i class="fa fa-calendar mr-5 text-theme-colored2"></i>< ?php $date = $rownewse['postdate'];	echo date("jS M Y", strtotime($date)); ?></li>
                              <li><i class="fa fa-bookmark mr-5 text-theme-colored2"></i><a href="news.php?nncategory_id=1&News">News</a></li> 
                            </ul>
                  
                </div>
              </div> < ?php $count++; } ?> -->
			  
			   
 
		</div>           
		


            <div class="col-md-3">             
              <article class="post clearfix mb-5">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <a href="events.php?id=42&e-Tuesdays"><img src="images/gallery/etuesday2022fe.jpg" alt="" class="img-responsive img-fullwidth"> </a>
                  </div>                    
                </div>
                <div class="entry-content p-15">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h5 class="entry-title text-white  font-weight-600 m-0 mt-5"><a href="events.php?id=42&e-Tuesdays">e-Tuesdays</a></h5>                            
                      </div>
                    </div>
                  </div>
                  <p class="mt-5"><p class="text-gray">DMCG E learning unit presents another innovative and exciting initiative with fun filled activities, Q and A sessions, microlearning trainings, and Discussion forums on..</p>
</p> 
                </div>
              </article>
             
            </div>
			            <div class="col-md-3">             
              <article class="post clearfix mb-5">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <a href="events.php?id=35&New teachers induction workshop"><img src="images/gallery/new_teacherfeatured.jpg" alt="" class="img-responsive img-fullwidth"> </a>
                  </div>                    
                </div>
                <div class="entry-content p-15">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h5 class="entry-title text-white  font-weight-600 m-0 mt-5"><a href="events.php?id=35&New teachers induction workshop">New teachers induction workshop</a></h5>                            
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">The &#39;New teachers Workshop&#39; was conducted on 3rd and 4th of September 2022, at Rashed Hospital to understand the principle of learning,</p> 
                </div>
              </article>
             
            </div>
			 
			
			
			
          </div>
        </div>
      </div>
    </section>


<!-- Section: Mission -->

    <section id="mission">

      <div class="container-fluid pt-0 pb-0">

        <div class="row equal-height">

          <div class="col-sm-6 col-md-6 pull-right xs-pull-none bg-theme-colored">

            <div class="pt-20 pb-20 pl-50 pr-80 p-md-30">

              <h2 class="text-white">Why <span class="text-theme-colored2">Choose</span> Us?</h2><div class="double-line-bottom-theme-colored-2 mb-30"></div>

              <div class="row mtli-row-clearfix"> 

                  <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">

				   <div class="col-xs-12">

				   <p>Dubai Medical College for Girls is the first private college awarding degree of Medicine & Surgery in the United Arab Emirates.</p>

                  <div class="icon-box left media p-0 mb-20"> 

                    <a class="media-left pull-left flip mr-20" href="#"><i class="pe-7s-diamond text-theme-colored2 font-weight-600"></i></a>

                    <div class="media-body">

                      <h4 class="media-heading text-white heading mb-10">Quality of Education</h4>

                      <p>The programme is delivered through a range of innovative and traditional teaching methods.</p>

                    </div>

                  </div>

                </div>

               

               <div class="col-xs-12">

                  <div class="icon-box left media p-0 mb-20"> 

                    <a class="media-left pull-left flip mr-20" href="#"><i class="pe-7s-note2  text-theme-colored2 font-weight-600"></i></a>

                    <div class="media-body">

                      <h4 class="media-heading text-white heading mb-10">Patient contact throughout your degree</h4>

                      <p>You will have direct contact with patients from the first term. </p>

                    </div>

                  </div>

                </div>

                <div class="col-xs-12">

                  <div class="icon-box left media p-0 mb-20"> 

                    <a class="media-left pull-left flip mr-20" href="#"><i class="pe-7s-menu text-theme-colored2 font-weight-600"></i></a>

                    <div class="media-body">

                      <h4 class="media-heading text-white heading mb-10">Physical facilities</h4>

                      <p>including teaching facilities, research laboratories, clinical skills laboratories, library and IT facilities.</p>

                    </div>

                  </div>

                </div>

                

                <div class="col-xs-12">

                  <div class="icon-box left media p-0 mb-40"> 

                    <a class="media-left pull-left flip mr-20" href="#"><i class="pe-7s-science text-theme-colored2 font-weight-600"></i></a>

                    <div class="media-body">

                      <h4 class="media-heading text-white heading mb-10">Innovation, Technology</h4>

                      <p>A state-of-the-art clinical simulation and learning center designed as an actual modern hospitalr</p>

                    </div>

                  </div>

                </div> 

              </div>

			  <div class="col-xs-4 col-md-4 col-lg-4"  style="padding-left:5px; padding-right:5px"> 

			  <table width="100%" border="0" cellspacing="5" cellpadding="5">

  <tr>

    <td><a href="https://lootah.sharepoint.com/sites/DMCPublications" target="_blank"><img class="img-fullwidth" src="images/ief.jpg" alt=""></a></td>

  </tr>

  <tr>

    <td>&nbsp;</td>

  </tr>

  <tr>

    <td><a href="https://dmcg.edu/dmcghub/" target="_blank"><img class="img-fullwidth" src="images/itp.jpg" alt=""></a></td>

  </tr>

  <tr>

    <td>&nbsp;</td>

  </tr>

  <tr>

    <td><a href="collegem.php" target="_blank"><img class="img-fullwidth" src="images/imag.jpg" alt=""></a></td>

  </tr>

  <tr>

    <td>&nbsp;</td>

  </tr>

  <tr>

    <td><img class="img-fullwidth" src="images/mes.jpg" alt=""></td>

  </tr>

</table> 

			  </div>

			  

			  </div>

            </div>

          </div> 

          <div class="col-sm-6 col-md-6 p-0 bg-img-cover" data-bg-img="images/bg/homeimg3.jpg">

          </div>

        </div>

      </div>

    </section>



     

	

     

    <!-- Divider: Call To Action -->

    <section class="bg-theme-colored2">

      <div class="container pt-0 pb-0">

        <div class="row">

          <div class="col-md-12">

            <!-- Section: Clients -->

            <div class="clients-logo transparent text-center" style="padding:10px;">

			<table width="100%" border="0" align="center" cellpadding="5" cellspacing="5">

  <tr>

    <td><a href="https://search.ebscohost.com/"><img src="images/hhhhh.jpg" alt="" style="height:55px;"></a></td>

    <td><a href="goto_UpToDate.php"><img src="images/lib_uptodate.jpg" alt="" style="height:55px;"></a></td>

    <td><a href="https://online.lexi.com/lco/action/login"><img src="images/h2.jpg" alt="" style="height:55px;"></a></td>

    <td><a href="https://www.amboss.com/int/campus/dubai-medical-college"><img src="images/lib_amboss.jpg" alt="" style="height:55px;"></a></td>

  </tr>

</table>

            

            </div>

        </div>

      </div>

    </section>

  <!-- end main-content -->

  </div>

  <!-- Footer -->

  <footer id="footer" class="footer fixed-footer" data-bg-color="#212331">
    <div class="container pt-40 pb-10">
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-5 mb-20" alt="" src="images/logo-white-footer.png">
            <p>Muhaisanah 1, Al Mizhar, Dubai.</p>
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">9714-2120555</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored2 mr-5"></i> <a class="text-gray" href="#"> dmcg@dmcg.edu</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">www.dmcg.edu</a> </li>
            </ul>            
            <ul class="styled-icons icon-sm icon-bordered icon-circled clearfix mt-10">
              <li><a href="https://www.facebook.com/dmcg.edu" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/dmc_edu" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/school/dubai-medical-college" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.instagram.com/dubaimedicalcollegeforgirls/" target="_blank"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Useful Links</h4>
            <ul class="angle-double-right list-border">
              <li><a href="academics.php?pageid=21&ProgramDetails">MBBCH Program</a></li>
              <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>
              <li><a href="main.php?pageid=12&VisionMission">Vision & Mission</a></li>
              <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li> 
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
		    <h4 class="widget-title line-bottom-theme-colored-2">Jobs Vacancies</h4>
            <div class="latest-posts">
			  


              <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Student Counsellor</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Career Guidance & Alumni Affairs</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			    
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Opening Hours</h4>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span> Mon - Thu :  </span>
                  <div class="value pull-right"> 7.30 AM to 3.30 PM </div>
                </li>
                <li class="clearfix"> <span> Fri :</span>
                  <div class="value pull-right"> 7.30 AM to 12.00 Noon </div>
                </li> 
                <li class="clearfix"> <span> Sat -Sun : </span>
                  <div class="value pull-right bg-theme-colored2 text-white closed"> Closed </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
	


    <div class="footer-bottom" data-bg-color="#2b2d3b">
      <div class="container pt-5 pb-10">
        <div class="row">
          <div class="col-md-6">
            <p class="font-12 text-black-777 m-0 sm-text-center">Copyright &copy; DMCG. All Rights Reserved. Website updated 13/11/2022</p>
          </div>
          <div class="col-md-6 text-right">
            <div class="widget no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12">
                <li>
                  <a href="#">Terms & Conditions</a>
                </li>
                <li>|</li>
                <li>
                  <a href="dmcg.php?pageid=86&Privacy Policy">Privacy Policy</a>
                </li> 
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>

</div>

<!-- end wrapper -->



<!-- Footer Scripts -->

<!-- JS | Custom script for all pages -->

<script src="js/custom.js"></script>



 



</body>

</html>