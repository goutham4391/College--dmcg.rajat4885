



 
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-86S09WJT92"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-86S09WJT92');
</script>
<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Dubai Medical College for Girls is the first college to award a degree in medicine & surgery in the UAE  " />
<meta name="keywords" content=" Bachelor in Medicine, Surgery, MBBCh, First Medical College in UAE,  MBBS, education,university,educational,learn,Dubai Medical College for Girls, Dubai, UAE, teaching,medical education, Professional Practice, Clinical, Biomedical Science,  Clinical Science, Health and Behavioral Sciences, Islamic values, research" />
<meta name="author" content="Dubai Medical College for Girls' IT Department" />
<!-- Page Title --> 
<title>Welcome to Dubai Medical College for Girls  - Jobs</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link href="css/menuzord-megamenu.css" rel="stylesheet"/>
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
 
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->
 

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-color-set3.css" rel="stylesheet" type="text/css">

<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>
 

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="has-fixed-footer">
<div id="wrapper" class="clearfix">  
  
  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top bg-theme-colored2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="widget text-white">
              <ul class="list-inline xs-text-center text-white">
                <li class="m-0 pl-10 pr-10"> <a href="#" class="text-white"><i class="fa fa-phone text-white"></i>+9714-2120555</a> </li>
                <li class="m-0 pl-10 pr-10"> 
                  <a href="#" class="text-white"><i class="fa fa-envelope-o text-white mr-5"></i> dmcg@dmcg.edu</a> 
                </li>
              </ul>
            </div>
          </div> 
          <div class="col-md-6">
            <ul class="list-inline sm-pull-none sm-text-center text-right text-white mb-sm-20 mt-10">
			<li> <a href="jobs.php" class="text-white">Careers</a> | </li>
			<li> <a href="https://dmcg.edu/helpdesk/" target="_blank"  class="text-white"> IT Helpdesk</a> | </li>
			<li class="dropdown">
                  <a href="#" class="dropdown-toggle text-white" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Campus Logins <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="https://dmug.brightspace.com/d2l/login" target="_blank"><i class="fa fa-graduation-cap mr-5"></i> LMS Login</a></li>
                    <!--<li><a href="#"><i class="fa fa-edit mr-5"></i> SIS Login</a></a></li>-->
                    <li><a href="https://www.office.com/?auth=2" target="_blank"><i class="fa fa-envelope mr-5"></i> Office 365</a></li> 
                    
                  </ul>
                </li>             
            </ul>
          </div>
        </div>
      </div>
    </div>    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default"><a class="menuzord-brand pull-left flip mt-sm-10 mb-sm-20" href="index.php"><img src="images/logo-dmc.png" alt=""></a>
            
<ul class="menuzord-menu">
              <li><a href="index.php">Home</a> 
              </li>
              <li><a href="#">About Us </a>
                <ul class="dropdown">
                <li><a href="main.php?pageid=74&AboutDmcg">About DMCG</a></li>
                <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>				
				 <li><a href="main.php?pageid=13&DeansMessage">Dean's Message</a></li>
				 <li><a href="main.php?pageid=17&BoardTrustees">Board of Trustees</a></li>		 
				 <li><a href="main.php?pageid=73&Leadership">DMCG Leadership</a></li>
                 <li><a href="main.php?pageid=12&VisionMission">The Vision &amp; Mission</a></li>
				 <li><a href="main.php?pageid=16&GoalsObjectives">Goals and Objectives</a></li>	
				 <li><a href="main.php?pageid=15&CollegePublications">College Publications</a></li>
				 <li><a href="main.php?pageid=18&OrganizationStructure">Organization Structure</a></li>			 
				 <li><a href="main.php?pageid=14&AboutDubai">About Dubai</a></li>
                </ul>
              </li>
              <li><a href="#">Academics</a>
                <ul class="dropdown">
                  <li><a href="academics.php?pageid=22&ProgramLearning">MBBCH</a>
                    <ul class="dropdown">
					  <li><a href="#">Calendars</a>
					   <ul class="dropdown">
					   <li><a href="academics.php?pageid=19&AcademicCalendar">Academic Calendar</a></li>
                      <li><a href="academics.php?pageid=20&EventsCalendar">Events Calendar</a></li>
					  <li><a href="academics.php?pageid=85&ExaminationCalendar">Examination Calendar</a></li></ul>
					  </li> 
					  <!--<li><a href="academics.php?pageid=21&ProgramDetails">Program Details</a></li>-->
					  <li><a href="academics.php?pageid=22&ProgramLearning">Program Learning Outcomes</a></li>
					  <li><a href="academics.php?pageid=23&TeachingPlan">Teaching Plan</a></li>
					  <li><a href="academics.php?pageid=24&CourseDescription">Course Description</a></li>
					  <li><a href="academics.php?pageid=79&Timetables">Timetables</a></li>
					  <li><a href="academics.php?pageid=84&CourseCatalogue">Course Catalogue</a></li>
					  <li><a href="academics.php?pageid=87&StudyGuide">Study Guide</a></li>
					  <li><a href="academics.php?pageid=81&GraduationCriteria">Graduation Criteria</a></li>
					  <li><a href="academics.php?pageid=82&AcademicFaculty">Academic Faculty & Staff</a></li>
					  <li><a href="academics.php?pageid=83&AdjunctFaculty">Adjunct Faculty Manual</a></li>
                    </ul>
                  </li>                  
                </ul>
              </li> 
              <li><a href="#">Life At Campus</a>
                <ul class="dropdown">  
                  <li><a href="campus.php?pageid=51&Departments">Departments</a></li>
				  <li><a href="campus.php?pageid=75&StudentAffairs">Student Affairs</a>
                    <ul class="dropdown">                      
				    <li><a href="campus.php?pageid=36&CareerGuidance">Career Guidance</a></li> 
				 	<li><a href="campus.php?pageid=35&StudentCounselling">Student Counselling</a></li> 
				 	<li><a href="campus.php?pageid=76&StudentServices">Student Support Services</a></li> 
				 	<li><a href="campus.php?pageid=34&Hostel">Hostel Facilities</a></li> 			  
                    </ul>
                  </li>
				  <li><a href="campus.php?pageid=80&SimulationCenter">Simulation Center</a></li>
				   <li><a href="campus.php?pageid=32&LearningCenter">Learning Center</a></li>
                  <li><a href="campus.php?pageid=33&FacilitiesDHA">Facilities at DHA</a></li>
<li><a href="campus.php?pageid=78&TeachingFacilities">Teaching Facilities</a></li>
                </ul> 
              </li>
			  <li><a href="#">Research</a>
                <ul class="dropdown"> 
				 <!--<li><a href="research.php?pageid=37&Director+of+Research">Director of Research</a></li>--> 
				 <li><a href="research.php?pageid=38&AimofResearch">Aim of Research at DMCG</a></li>
				 <li><a href="research.php?pageid=39&ResearchCollaborations">Research Collaborations</a></li>
				 <li><a href="research.php?pageid=40&ResearchSupport">Research Support</a></li>
				 <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li>
				  <li><a href="research.php?pageid=42&Publications">DMCG Academic Publications</a></li>
				 <li><a href="research.php?pageid=45&Researchpolicy">Research Policy</a></li>
                </ul>
              </li>
			  <li><a href="#">Library</a>
                <ul class="dropdown">  
                  <li><a href="library.php?pageid=31&DMCGLibrary">DMCG Library</a></li>
				  <li><a href="library.php?pageid=47&EResources">E-Resources</a></li>
				  <li><a href="#">E-Journals</a>
				   <ul class="dropdown">
                      <li><a href="journals1.php">Medline Complete</a></li> 
					  <li><a href="journals3.php">Open Access Journals </a></li>
					  <li><a href="library.php?pageid=49&OtherJournals">Other Journals </a></li>
                    </ul></li>
                </ul> 
              </li>
			  <li><a href="#">Media</a>
                <ul class="dropdown"> 
                  <li><a href="announcements.php">Announcements</a></li>
                  <!--<li><a href="media.php?nncategory_id=1&News">News</a></li>-->
                  <li><a href="event.php?ecategory_id=1&DMCG Events">Events</a></li>
				 <li><a href="collegem.php">College Magazines</a></li> 
				 <li><a href="event.php?ecategory_id=2&DMCG Updates">DMCG Updates</a></li> 
                </ul>
              </li>
			  <li><a href="contact.php">Contact</a>               
              </li>
            </ul>
					
		          </nav>
        </div>
      </div>
    </div>
  </header>
  
 
  
  
 
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-white-7" data-bg-img="images/bg/bg4.jpg">
      <div class="container pt-50 pb-30">
        <!-- Section Content -->
        <div class="section-title">
          <div class="row"> 
            <div class="col-md-6 text-left flip xs-text-center">
              <h5 class="sub-title">Career opportunities</h5>
          <h2 class="title">Jobs</h2>
            </div>
            <div class="col-sm-4">
              <ol class="breadcrumb text-right sm-text-center text-black mt-10">
                <li><a href="#">Home</a></li>
                <li><a href="#">About Us</a></li>
                <li class="active text-theme-colored">Jobs</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
    
	 
	
	
	<section>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div id="accordion1" class="panel-group accordion transparent">
               


				
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion11"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion11"><i class="fa fa-chevron-circle-right"></i> Student Counsellor</a></h4>
</div>

<div aria-expanded="true" class="panel-collapse collapse in" id="accordion11" role="tablist">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Student Counsellor</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-map-marker text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Location:</h5>

	<p>DMCG</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>Open until filled</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Responsible:</h5>

<p class="text-gray">Listen to students&rsquo; concerns about academic, emotional or social problems.</p>

<h5 class="mt-30">Job Purpose:</h5>

<p class="text-gray">The objective of the job is to able to identify and address needs for academic and emotional support for individual students and groups. Implementing prevention and information programs as needed.</p>

<h5 class="mt-30">Job Description:</h5>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Listening to students&rsquo; academic, emotional, social, and behavioral concerns in an open and non-judgmental way.</li>
	<li>Working directly with students to develop solutions and set achievable goals.</li>
	<li>Assisting with conflict mediation and resolution between students, students and teachers, or parents and teachers to ensure students&rsquo; goals are not disrupted.</li>
	<li>Providing one-on-one career guidance and skills assessment to assist with career development.</li>
	<li>Helping students to prepare for admissions applications and tests.</li>
	<li>Providing students with materials related to a career of their choice or career counseling to suit their skills.</li>
	<li>Developing, monitoring, and assisting with counseling programs.</li>
	<li>Offering referrals to outside resources, such as for mental health, substance abuse, or vocational-related activities.</li>
	<li>Reporting student issues to the appropriate state authorities if neglect or abuse is suspected.</li>
	<li>Areas of support by Counsellor:
	<ul class="list theme-colored">
		<li>a. Professional and personal development.</li>
		<li>b. Academic medicine and research.</li>
		<li>c. Psychological and social wellness (through referrals).</li>
		<li>d. Career counselling, planning and opportunities through networking and professional link.</li>
	</ul>
	</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Bachelor&rsquo;s degree in Counseling.</li>
	<li>Master&rsquo;s Degree in Counseling may be advantageous.</li>
	<li>Minimum of 2 years&rsquo; professional counseling experience, preferably in an educational field.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Knowledge of placement testing and career, personal, and educational assessment.</li>
	<li>Experience with counseling principles, techniques, and practices as applied to students&rsquo; problems and developmental needs.</li>
	<li>Excellent active listening and communication skills.</li>
	<li>Patient, friendly, and accommodating personality.</li>
	<li>Social perceptiveness and an understanding of body language.</li>
	<li>Excellent interpersonal and mediation skills.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion14"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion14"><i class="fa fa-chevron-circle-right"></i> Executive Secretary</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion14" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Executive Secretary</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-map-marker text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Location:</h5>

	<p>DMCG</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Responsible:</h5>

<p class="text-gray">Day-to-day implementation of the Dean&rsquo;s Office activities and coordination with the academic departments which report to the Dean.</p>

<h5 class="mt-30">Job Description:</h5>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">Under general supervision, coordinates, oversees, and/or performs a wide variety of administrative support activities for an academic dean. Assignments may be confidential in nature. Provides and coordinates staff and office support. Coordinates special events. May serve on a variety of academic committees in a support capacity.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Provides staff and office support for the dean, to include screening and handling telephone communications, greeting and directing visitors, and dealing with administrative problems and inquiries, as appropriate; serves as a primary point of contact and liaison between the office, students, and external constituencies on a range of day-to-day issues.</li>
	<li>Organizes and facilitates meetings and special events; schedules and coordinates dates and times, venues, attendance, agendas, and facilities; takes minutes, and provides administrative support and follow-up on matters arising from meetings.</li>
	<li>Composes and prepares written documentation and correspondence for the office; screens and evaluates incoming and outgoing correspondence and prepares responses as appropriate.</li>
	<li>Schedules and coordinates dean&rsquo;s appointments and/or travel arrangements and coordinates and oversees daily office activities.</li>
	<li>Gathers, enters, and/or updates data to maintain departmental records and databases, as appropriate; establishes and maintains files and records for the office.</li>
	<li>Leads and guides the work of lower graded staff and/or student employees, as appropriate; may participate in training and evaluative sessions.</li>
	<li>Carries out and coordinates administrative activities associated with academic affairs, such as tenure, contracts, and promotion of faculty reporting to the dean.</li>
	<li>Coordinates and oversees the day-to-day management of supplies, equipment, and facilities for the organization, as appropriate, to include maintenance, inventory management, logistics, security, and related activities.</li>
	<li>Enhances professional growth and development through participation in educational programs, current literature, in-service meetings, and workshops.</li>
	<li>Performs miscellaneous job-related duties as assigned.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Bachelor&rsquo;s Degree</li>
	<li>Minimum of 2 years&rsquo; professional experience, preferably in the same field.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Requires excellent communication skill in Arabic (speaking, reading, and writing)</li>
	<li>Requires excellent communication skill in English (speaking, reading, and writing)</li>
	<li>Knowledge of planning and scheduling techniques.</li>
	<li>Knowledge of supplies, equipment, and/or services ordering and inventory control.</li>
	<li>Strong interpersonal and communication skills and the ability to work effectively with a wide range of constituencies in a diverse community.</li>
	<li>Knowledge of current and emerging trends in technologies, techniques, issues, and approaches in area of expertise.</li>
	<li>Records maintenance skills.</li>
	<li>Database management skills.</li>
	<li>Skill in organizing resources and establishing priorities.</li>
	<li>Word processing and/or data entry skills.</li>
	<li>Ability to create, compose, and edit written materials.</li>
	<li>Knowledge of office management principles and procedures.</li>
	<li>Ability to coordinate and organize meetings and/or special events.</li>
	<li>Knowledge of academic administrative principles and procedures.</li>
	<li>Strong public relations, organizational, oral, and written communication skills.</li>
	<li>Ability to work with people from diverse backgrounds.</li>
	<li>Ability to maintain a high degree of confidentiality.</li>
	<li>Ability to prioritize and balance multiple projects.</li>
	<li>Proficiency with PC operating systems, specifically Microsoft Office (Excel spreadsheets, Word docs, Outlook)</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion15"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion15"><i class="fa fa-chevron-circle-right"></i> Career Guidance &amp; Alumni Affairs</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion15" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Career Guidance &amp; Alumni Affairs</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-map-marker text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Location:</h5>

	<p>DMCG</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-1">Responsible:</h5>

<p class="text-gray">All activities and relations related to career guidance and alumni.</p>

<h5 class="mt-30">Job Description:</h5>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">The objective of the job is to link the college&rsquo;s outputs to the job market.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Obtaining information about various local, regional, and international opportunities for specialization including:
	<ul class="list theme-colored">
		<li>1. The bodies regulating these opportunities.</li>
		<li>2. Necessary requirements including exams and licensing requirements for the above.</li>
	</ul>
	</li>
	<li>Educate and empower students to develop, implement, and continuously evaluate their academic and career goals.</li>
	<li>Facilitate students transition to employees.</li>
	<li>Maximize opportunities for students to develop connections with potential employers.</li>
	<li>Provide career development and networking opportunities.</li>
	<li>&nbsp;</li>
	<li>Help students and alumni develop soft skills by offering career related workshops and, strengthen their self-marketing tools whilst expanding their market knowledge base through a better understanding of the available job search strategies.</li>
	<li>To develop students&rsquo; soft skills including communication, team building, leadership, and presentation.</li>
	<li>To conduct trainings and workshops for both current students and alumni to improve their personal, interpersonal, situational and employability skills.</li>
	<li>To maintain updated repository of alumni.</li>
	<li>To encourage alumni to participate in various activities and events in college.</li>
	<li>Utilize the alumni unit to get alumni input and provides plans for engaging them in college activities specially those related to current student career planning, Job fairs, meet a &ldquo;success story&rdquo;, meet the expert.</li>
	<li>Invite specialists from the identified opportunities to speak to the students.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Bachelor&rsquo;s Degree</li>
	<li>Minimum of 2 years&rsquo; professional experience, preferably in the same field.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Job-seeking and work skills.</li>
	<li>Training in entrepreneurial and self-employment skills.</li>
	<li>Training communication skills.</li>
	<li>Language training.</li>
	<li>Computer Application Training.</li>
	<li>Awareness, Community and Volunteer Programs.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion16"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion16"><i class="fa fa-chevron-circle-right"></i> Executive Secretary</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion16" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Executive Secretary</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-map-marker text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Location:</h5>

	<p>DMCG</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Responsible:</h5>

<p class="text-gray">Day-to-day implementation of the Dean&rsquo;s Office activities and coordination with the academic departments which report to the Dean.</p>

<h5 class="mt-30">Job Description:</h5>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">Under general supervision, coordinates, oversees, and/or performs a wide variety of administrative support activities for an academic dean. Assignments may be confidential in nature. Provides and coordinates staff and office support. Coordinates special events. May serve on a variety of academic committees in a support capacity.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Provides staff and office support for the dean, to include screening and handling telephone communications, greeting and directing visitors, and dealing with administrative problems and inquiries, as appropriate; serves as a primary point of contact and liaison between the office, students, and external constituencies on a range of day-to-day issues.</li>
	<li>Organizes and facilitates meetings and special events; schedules and coordinates dates and times, venues, attendance, agendas, and facilities; takes minutes, and provides administrative support and follow-up on matters arising from meetings.</li>
	<li>Composes and prepares written documentation and correspondence for the office; screens and evaluates incoming and outgoing correspondence and prepares responses as appropriate.</li>
	<li>Schedules and coordinates dean&rsquo;s appointments and/or travel arrangements and coordinates and oversees daily office activities.</li>
	<li>Gathers, enters, and/or updates data to maintain departmental records and databases, as appropriate; establishes and maintains files and records for the office.</li>
	<li>Leads and guides the work of lower graded staff and/or student employees, as appropriate; may participate in training and evaluative sessions.</li>
	<li>Carries out and coordinates administrative activities associated with academic affairs, such as tenure, contracts, and promotion of faculty reporting to the dean.</li>
	<li>Coordinates and oversees the day-to-day management of supplies, equipment, and facilities for the organization, as appropriate, to include maintenance, inventory management, logistics, security, and related activities.</li>
	<li>Enhances professional growth and development through participation in educational programs, current literature, in-service meetings, and workshops.</li>
	<li>Performs miscellaneous job-related duties as assigned.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Bachelor&rsquo;s Degree</li>
	<li>Minimum of 2 years&rsquo; professional experience, preferably in the same field.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Requires excellent communication skill in Arabic (speaking, reading, and writing)</li>
	<li>Requires excellent communication skill in English (speaking, reading, and writing)</li>
	<li>Knowledge of planning and scheduling techniques.</li>
	<li>Knowledge of supplies, equipment, and/or services ordering and inventory control.</li>
	<li>Strong interpersonal and communication skills and the ability to work effectively with a wide range of constituencies in a diverse community.</li>
	<li>Knowledge of current and emerging trends in technologies, techniques, issues, and approaches in area of expertise.</li>
	<li>Records maintenance skills.</li>
	<li>Database management skills.</li>
	<li>Skill in organizing resources and establishing priorities.</li>
	<li>Word processing and/or data entry skills.</li>
	<li>Ability to create, compose, and edit written materials.</li>
	<li>Knowledge of office management principles and procedures.</li>
	<li>Ability to coordinate and organize meetings and/or special events.</li>
	<li>Knowledge of academic administrative principles and procedures.</li>
	<li>Strong public relations, organizational, oral, and written communication skills.</li>
	<li>Ability to work with people from diverse backgrounds.</li>
	<li>Ability to maintain a high degree of confidentiality.</li>
	<li>Ability to prioritize and balance multiple projects.</li>
	<li>Proficiency with PC operating systems, specifically Microsoft Office (Excel spreadsheets, Word docs, Outlook)</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion17"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion17"><i class="fa fa-chevron-circle-right"></i> Assistant Professor </a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion17" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Assistant Professor</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-building-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Department:</h5>

	<p>Parasitology</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Full-time Faculty</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>01-Sep-2021</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-30">Job Description:</h5>

<p class="text-gray">Dubai Medical College for Girls invites applications for the position of Assistant Professor in the Parasitology Department.</p>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">This Full-Time Faculty position will be responsible for facilitating meaningful learning experiences for DMCG students, encourage a culture of learning environment that fosters Islamic values, and promotes high standards of academic excellence.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<p class="text-gray">As Full-time Teaching Faculty</p>

<ul class="list theme-colored">
	<li>Facilitate student learning, provide effective instruction and perform evaluations of students.</li>
	<li>Develop course materials, including lesson plans, assignments, quizzes, tests, course handouts, and presentations.</li>
	<li>Facilitate student learning online, and in class, provide effective instruction and perform evaluations of students.</li>
	<li>Conduct teaching per college requirements.</li>
	<li>Conduct assessments as outlined in the course syllabus.</li>
	<li>Support student learning and advise students to help them to achieve their academic goals.</li>
	<li>Participate in program reviews, curriculum development, and research activities.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Ph.D. or Medicine Doctorate in Parasitology form an accredited university.</li>
	<li>Post graduate Degree in Medical Education.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Teaching experience at university level.</li>
	<li>English language proficiency.</li>
	<li>Excellent Computer Skills</li>
	<li>Excellent communication skills, with a proven track, record of effective teaching, online teaching, class management, and course delivery.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion18"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion18"><i class="fa fa-chevron-circle-right"></i> Part-Time Faculty Vacancy</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion18" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Part-Time Faculty Vacancy</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Part-Time Faculty</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Starting Date:</h5>

	<p>07-April-2021</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<p class="text-gray">Applications are invited for part-time faculty positions to begin in Summer of 2021-22 (starting from 15 June &ndash; 15 July 2021) for MBBCh and BPharm students in DMCG and DPC respectively. We are looking for applicants to teach the following courses:</p>

<p class="text-gray">&ndash; UAE Society and<br />
&ndash; Arabic Language.</p>

<p class="text-gray">Preference will be given to candidates with a Masters/PhD in Humanities/Social Sciences/Arabic Language Studies The candidates are expected to teach a two-credit hour course, which is equivalent to 30 hours of teaching i.e. 4 weeks of the academic calendar.</p>

<p class="text-gray">Dubai Medical College for Girls and its academic degree programs are accredited by the UAE Ministry of Education &ndash; Higher Education Affairs.</p>

<p class="text-gray">Interested candidates must send an up-to-date CV to the following address:<br />
<a href="mailto:recruitment.dmu@dmcg.edu">recruitment.dmu@dmcg.edu </a></p>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion17"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion19"><i class="fa fa-chevron-circle-right"></i> Quality Assurance Officer</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion19" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Quality Assurance Officer</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Full-time Faculty</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>15-April-2021</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>

<p class="text-gray">Dubai Medical College for Girls invites applicants to apply for the position of Quality Assurance Officer. An ideal candidate must be qualified in quality assurance with a medical education degree/degree in education and minimum 3 years&rsquo; experience in education sector preferable medical education.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Manage quality standards of the clinical phase of the college in conformance with accreditation requirements of UAE and international benchmarks.</li>
	<li>Manage the development and implementation of the policies and procedures in collaboration with the Institutional Effectiveness Office.</li>
	<li>Support the clinical phase in internal and external reviews for Ministry Licensure, accreditation and audits (e.g. institutional reviews, curricular reviews, performance reviews).</li>
	<li>Monitor and oversee implementation of policies and plans in the clinical phase and report to the Associate Dean of Clinical Affairs.</li>
	<li>Actively engage with the College&rsquo;s academic staff at all levels to collect institutional data, and prepare summary reports based on analysis of student assessment and feedback.</li>
	<li>Prepare periodic reports and related information for communication for the purpose of external reporting and institutional reviews.</li>
	<li>Coordinate with other senior academic administrative staff in relation to College publications &ndash; e.g. catalog, QA manual, faculty and student handbook.</li>
	<li>Conduct regular qualitative and quantitative research to ensure that performance indicators as set and achieved.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Must hold a Bachelor or Master degree in Quality Assurance.</li>
	<li>Masters&rsquo; degree in medical education/health professions education/degree in education.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Minimum 3 years of experience in quality assurance preferable in an undergraduate medical education setting.</li>
	<li>Strong command of English language written and verbal to prepare institutional reports.</li>
	<li>Report writing capabilities to meet the expectations of audiences within higher education external agencies.</li>
	<li>Excellent written and verbal interpersonal communication skills.</li>
	<li>Possess strong IT skills and data analytic skills.</li>
	<li>Ability to take significant initiative and to work independently as appropriate.</li>
	<li>Dealing with staff, students and external agencies in a courteous and professional manner.</li>
	<li>Dealing with all information relating to activities undertaken and information received in the strictest confidence.</li>
	<li>Complying with campus policies and procedures in relation to health and safety and data protection regulations.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion20"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion20"><i class="fa fa-chevron-circle-right"></i> Assistant Lecturer (DMCG Alumni preferred)</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion20" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Assistant Lecturer (DMCG Alumni preferred)</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Full-time Faculty</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>31-March-2021</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>
<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">The Assistant Lecturer is responsible for facilitating meaningful learning experiences for DMCG students, encourage a culture of learning environment that fosters Islamic values and promotes highest standards of academic excellence through research and community service.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Help teachers prepare lesson plans.</li>
	<li>Track student attendance and class schedules.</li>
	<li>Review material taught in class with individual students with learning challenges.</li>
	<li>Work with smaller groups of students for remedial teaching or reinforcing the learning process.</li>
	<li>Assist teachers with various tasks, like grading assignments and informing parents of their children&rsquo;s progress.</li>
	<li>Help students adjust, learn and socialize and report to teachers about possible behavioral issues.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Master&rsquo;s Degree.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Teaching experience at the university level.</li>
	<li>English language proficiency.</li>
	<li>Excellent communication skills, with proven track records in effective teaching, class management and course delivery.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion21"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion21"><i class="fa fa-chevron-circle-right"></i> Graphic Designer</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion21" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Graphic Designer</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Full-Time</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>31-March-2021</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Prepares work to be accomplished by gathering information and materials.</li>
	<li>Plans concept by studying information and materials.</li>
	<li>Illustrates concept by designing rough layout of art and copy regarding arrangement, size, type size and style, and related aesthetic concepts.</li>
	<li>Obtains approval of concept by submitting rough layout for approval.</li>
	<li>Prepares final layout by marking and pasting up finished copy and art.</li>
	<li>Ensures operation of equipment by completing preventive maintenance requirements, following institution instructions, troubleshooting malfunctions, calling for repairs.</li>
	<li>Maintains technical knowledge by attending design workshops, reviewing professional publications, and participating in professional societies.</li>
	<li>Contributes to team effort by accomplishing related results as needed.</li>
	<li>Translating client needs and branding strategies into design strategies.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Bachelor&rsquo;s degree in graphic design, education design, or equivalent experience.</li>
	<li>Five to eight years of experience in graphic design.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Strong graphic design skills.</li>
	<li>Layout skills.</li>
	<li>Analytical skills.</li>
	<li>Creativity.</li>
	<li>Flexibility.</li>
	<li>Deadline-oriented.</li>
	<li>Desktop publishing tools and graphic design software.</li>
	<li>Time-management skills.</li>
	<li>Communication skills.</li>
	<li>Handles rejection.</li>
	<li>Proficient in Adobe Photoshop.</li>
	<li>Proficient in Adobe Illustrator.</li>
	<li>Knowledge in HTML and PHP &amp; MySQL basics.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion22"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion22"><i class="fa fa-chevron-circle-right"></i> Teaching Assistant (DMCG alumni preferred)</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion22" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Teaching Assistant (DMCG alumni preferred)</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Full-Time</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>31-March-2021</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>

<p class="text-gray">Dubai Medical College for Girls invites applications for the position of Teaching Assistant.</p>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">The Teaching Assistant is responsible for facilitating meaningful learning experiences for DMCG students, encourage a culture of learning environment that fosters Islamic values and promotes highest standards of academic excellence through research and community service.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Help teachers prepare lesson plans.</li>
	<li>Track student attendance and class schedules.</li>
	<li>Review material taught in class with individual students with learning challenges.</li>
	<li>Work with smaller groups of students for remedial teaching or reinforcing the learning process.</li>
	<li>Escort and supervise students in field trips and school activities.</li>
	<li>Assist teachers with various tasks, like grading assignments and informing parents of their children&rsquo;s progress.</li>
	<li>Help students adjust, learn and socialize and report to teachers about possible behavioral issues.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>MBBCh</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Teaching experience at the university level.</li>
	<li>English language proficiency.</li>
	<li>Excellent communication skills, with proven track records in effective teaching, class management and course delivery.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion27"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion27"><i class="fa fa-chevron-circle-right"></i> Senior Academic Officer</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion27" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Senior Academic Officer</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-trophy text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Rank:</h5>

	<p>Professor</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>21-Oct-2020</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>

<p class="text-gray">Dubai Medical College for Girls invites applicants to apply for the position of Senior Academic Officer. An ideal candidate must be a medical doctor and clinical practitioner with experience in teaching undergraduate medical students.&nbsp;</p>

<h5 class="mt-0">Reporting line:</h5>

<p class="text-gray">This position will be reporting to the Dean.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Oversee the entire curriculum delivery in the 5 years of medical education for the MBBCh program</li>
	<li>Create a framework to monitor effective program delivery in the clinical setting so that graduate attributes are achieved.</li>
	<li>Ensure that clinical competencies are monitored and achieved in line with the recent advances in Competency Based Medical Education</li>
	<li>Lead the curriculum development and program review teams in the MBBCh program</li>
	<li>Assess and propose suggestions for strategy, resources, policies and faculty development strategies to enhance delivery of the curriculum</li>
	<li>To adapt and renew the curriculum according to the latest trends in medical education</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Must hold a professional medical degree</li>
	<li>Masters&rsquo; degree in medical education/health professions education.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Minimum 10 years of experience in leadership role in medical education in an undergraduate medical education setting.</li>
	<li>Excellent written, verbal and interpersonal communication skills</li>
	<li>Possess strong organizational and leadership skills</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion24"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion24"><i class="fa fa-chevron-circle-right"></i> Assistant / Associate Professor</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion24" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Assistant /Associate Professor</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-building-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Department:</h5>

	<p>Physiology</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Part-Time Faculty</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>20-Oct-2020</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>

<p class="text-gray">Dubai Medical College for Girls invites applications for the position of Assistant/Associate Professor in the Physiology Department.&nbsp;</p>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">This Part-Time Faculty position will be responsible for facilitating meaningful learning experiences for DMCG students, encourage a culture of learning environment that fosters Islamic values, and promotes high standards of academic excellence.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Facilitate student learning, provide effective instruction and perform evaluations of students.</li>
	<li>Develop course materials, including lesson plans, assignments, quizzes, tests, course handouts, and presentations.</li>
	<li>Facilitate student learning online, and in class, provide effective instruction and perform evaluations of students.</li>
	<li>Conduct teaching per college requirements.</li>
	<li>Conduct assessments as outlined in the course syllabus.</li>
	<li>Support student learning and advise students to help them to achieve their academic goals.</li>
	<li>Participate in program reviews, curriculum development, and research activities.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Ph.D. or Medicine Doctorate in Physiology form an accredited university.</li>
	<li>Post graduate Degree in Medical Education.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Teaching experience at university level.</li>
	<li>English language proficiency.</li>
	<li>Excellent Computer Skills</li>
	<li>Excellent communication skills, with a proven track, record of effective teaching, online teaching, class management, and course delivery.</li>
	<li>Applicant must be resident of the UAE.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion25"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion25"><i class="fa fa-chevron-circle-right"></i> Assistant Professor / Associate Professor / Professor</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion25" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Assistant Professor / Associate Professor / Professor</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-building-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Department:</h5>

	<p>Anatomy</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Full-Time Faculty</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>Closed</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>

<p class="text-gray">Dubai Medical College for Girls invites applications for the position of Assistant Professor / Associate Professor / Professor in the Anatomy Department.&nbsp;</p>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">This Full-Time Faculty position will be responsible for facilitating a meaningful learning experiences for DMCG students, encourage a culture of learning environment that fosters Islamic values, and promotes high standards of academic excellence.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Facilitate student learning, provide effective instruction and perform evaluations of students.</li>
	<li>Develop course materials, including lesson plans, assignments, quizzes, tests, course handouts, and presentations.</li>
	<li>Facilitate student learning online and in class, provide effective instruction, and perform evaluations of students.</li>
	<li>Develop course materials, including lesson plans, assignments, quizzes, tests, course handouts, and presentations.</li>
	<li>Conduct teaching per the college requirements (taking attendance, grading, preparing student materials, etc.).</li>
	<li>Conduct assessments as outlined in the course syllabus.</li>
	<li>Support student learning and advise students to help them to achieve their academic goals.</li>
	<li>Participate in program reviews, curriculum development, and research activities.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Ph.D. or Medicine Doctorate in Anatomy.</li>
	<li>Post Graduate Degree in Medical Education.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Teaching experience at university level.</li>
	<li>English language proficiency.</li>
	<li>Excellent Computer Skills</li>
	<li>Excellent communication skills, with a proven track, record of effective teaching, online teaching, class management, and course delivery.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
					
								
				
					<div class="panel">
<div class="panel-title"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion26"><span class="open-sub"></span></a>
<h4 class="icon-box-title pt-15 mt-0 mb-40"><a aria-expanded="true" class="active" data-parent="#accordion1" data-toggle="collapse" href="#accordion26"><i class="fa fa-chevron-circle-right"></i> Assistant Professor</a></h4>
</div>

<div aria-expanded="false" class="panel-collapse collapse" id="accordion26" role="tablist" style="height: 0px;">
<div class="panel-content"><!-- Job data from page-->
<div class="row">
<div class="col-md-3">
<div class="job-overview">
<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Title</h5>

	<p>Assistant Professor</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-building-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Department:</h5>

	<p>Microbiology</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-tasks text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Category:</h5>

	<p>Full-Time Faculty</p>
	</dd>
</dl>

<dl class="dl-horizontal">
	<dt><i class="fa fa-calendar-o text-theme-colored mt-5 font-15"></i></dt>
	<dd>
	<h5 class="mt-0">Job Close Date:</h5>

	<p>Closed</p>
	</dd>
</dl>
<a class="btn btn-dark mt-20" data-target="#myModal" data-toggle="modal" href="mailto:recruitment.dmu@dmcg.edu">Apply Now</a> <!-- Modal -->

<div class="modal fade" id="myModal" role="dialog" tabindex="-1">
<div class="modal-dialog" role="document">
<div class="modal-content p-30 pt-10">
<h3 class="text-center text-theme-colored mb-20">Apply Now</h3>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-9">
<div class="icon-box mb-0 p-0">
<h5 class="mt-0">Job Description:</h5>

<p class="text-gray">Dubai Medical College for Girls invites applications for the position of Assistant Professor/Associate Professor or Professor in the Parasitology.</p>

<h5 class="mt-0">Job Purpose:</h5>

<p class="text-gray">The Assistant Professor is responsible for facilitating meaningful learning experiences for DMCG students, encourage a culture of learning environment that fosters Islamic values, and promotes high standards of academic excellence.</p>

<h5 class="mt-1">Main Responsibilities:</h5>

<ul class="list theme-colored">
	<li>Facilitate student learning, provide effective instruction and perform evaluations of students.</li>
	<li>Develop course materials, including lesson plans, assignments, quizzes, tests, course handouts, and presentations.</li>
	<li>Facilitate student learning online and in class, provide effective instruction, and perform evaluations of students.</li>
	<li>Develop course materials, including lesson plans, assignments, quizzes, tests, course handouts, and presentations.</li>
	<li>Conduct teaching per the college requirements (taking attendance, grading, preparing student materials, etc.).</li>
	<li>Conduct assessments as outlined in the course syllabus.</li>
	<li>Support student learning and advise students to help them to achieve their academic goals.</li>
	<li>Participate in program reviews, curriculum development, and research activities.</li>
</ul>

<h5 class="mt-30">Preferred Qualification:</h5>

<ul class="list theme-colored">
	<li>Ph.D. or Medicine Doctorate in Parasitology.</li>
</ul>

<h5 class="mt-30">Expected Skills/Rank/Experience:</h5>

<ul class="list theme-colored">
	<li>Teaching experience at the university level.</li>
	<li>English language proficiency.</li>
	<li>Excellent computer skills.</li>
	<li>Excellent communication skills, with a proven track, record of effective teaching, online teaching, class management, and course delivery.</li>
</ul>

<p class="text-gray">To apply: Please send you CV to<br />
<a href="mailto:recruitment.dmu@dmcg.edu">recruitment.dmu@dmcg.edu</a></p>
</div>
</div>
</div>
</div>
</div>
</div>
					
				  
			   
          </div>
        </div>
      </div>
    </section>
  
  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
  <footer id="footer" class="footer fixed-footer" data-bg-color="#212331">
    <div class="container pt-40 pb-10">
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-5 mb-20" alt="" src="images/logo-white-footer.png">
            <p>Muhaisanah 1, Al Mizhar, Dubai.</p>
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">9714-2120555</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored2 mr-5"></i> <a class="text-gray" href="#"> dmcg@dmcg.edu</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">www.dmcg.edu</a> </li>
            </ul>            
            <ul class="styled-icons icon-sm icon-bordered icon-circled clearfix mt-10">
              <li><a href="https://www.facebook.com/dmcg.edu" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/dmc_edu" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/school/dubai-medical-college" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.instagram.com/dubaimedicalcollegeforgirls/" target="_blank"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Useful Links</h4>
            <ul class="angle-double-right list-border">
              <li><a href="academics.php?pageid=21&ProgramDetails">MBBCH Program</a></li>
              <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>
              <li><a href="main.php?pageid=12&VisionMission">Vision & Mission</a></li>
              <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li> 
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
		    <h4 class="widget-title line-bottom-theme-colored-2">Jobs Vacancies</h4>
            <div class="latest-posts">
			  


              <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Student Counsellor</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Career Guidance & Alumni Affairs</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			    
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Opening Hours</h4>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span> Mon - Thu :  </span>
                  <div class="value pull-right"> 7.30 AM to 3.30 PM </div>
                </li>
                <li class="clearfix"> <span> Fri :</span>
                  <div class="value pull-right"> 7.30 AM to 12.00 Noon </div>
                </li> 
                <li class="clearfix"> <span> Sat -Sun : </span>
                  <div class="value pull-right bg-theme-colored2 text-white closed"> Closed </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
	


    <div class="footer-bottom" data-bg-color="#2b2d3b">
      <div class="container pt-5 pb-10">
        <div class="row">
          <div class="col-md-6">
            <p class="font-12 text-black-777 m-0 sm-text-center">Copyright &copy; DMCG. All Rights Reserved. Website updated 13/11/2022</p>
          </div>
          <div class="col-md-6 text-right">
            <div class="widget no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12">
                <li>
                  <a href="#">Terms & Conditions</a>
                </li>
                <li>|</li>
                <li>
                  <a href="dmcg.php?pageid=86&Privacy Policy">Privacy Policy</a>
                </li> 
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

 <input type="hidden" name="ids" id="ids" value="1" readonly />
<script type="text/javascript">
var chatinput = document.getElementById("ids").value;
if (chatinput == "" || chatinput.length == 0 || chatinput == null)
{
    window.location = "index.php";
}
</script>

</body>
</html>