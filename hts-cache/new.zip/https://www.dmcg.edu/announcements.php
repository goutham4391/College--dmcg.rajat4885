



 
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head> 

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-86S09WJT92"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-86S09WJT92');
</script>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Dubai Medical College for Girls is the first college to award a degree in medicine & surgery in the UAE  " />
<meta name="keywords" content=" Bachelor in Medicine, Surgery, MBBCh, First Medical College in UAE,  MBBS, education,university,educational,learn,Dubai Medical College for Girls, Dubai, UAE, teaching,medical education, Professional Practice, Clinical, Biomedical Science,  Clinical Science, Health and Behavioral Sciences, Islamic values, research" />
<meta name="author" content="Dubai Medical College for Girls' IT Department" />

<!-- Page Title --> 
<title>Welcome to Dubai Medical College for Girls  - Announcements</title>

<!-- Favicon and Touch Icons -->
<link href="images/favicon.png" rel="shortcut icon" type="image/png">
<link href="images/apple-touch-icon.png" rel="apple-touch-icon">
<link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link href="css/menuzord-megamenu.css" rel="stylesheet"/>
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
 <link rel="stylesheet" href="css/components/bs-datatable.css" type="text/css" />
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->
 

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-color-set3.css" rel="stylesheet" type="text/css">

<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>
 

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="has-fixed-footer">
<div id="wrapper" class="clearfix">  
  
  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top bg-theme-colored2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="widget text-white">
              <ul class="list-inline xs-text-center text-white">
                <li class="m-0 pl-10 pr-10"> <a href="#" class="text-white"><i class="fa fa-phone text-white"></i>+9714-2120555</a> </li>
                <li class="m-0 pl-10 pr-10"> 
                  <a href="#" class="text-white"><i class="fa fa-envelope-o text-white mr-5"></i> dmcg@dmcg.edu</a> 
                </li>
              </ul>
            </div>
          </div> 
          <div class="col-md-6">
            <ul class="list-inline sm-pull-none sm-text-center text-right text-white mb-sm-20 mt-10">
			<li> <a href="jobs.php" class="text-white">Careers</a> | </li>
			<li> <a href="https://dmcg.edu/helpdesk/" target="_blank"  class="text-white"> IT Helpdesk</a> | </li>
			<li class="dropdown">
                  <a href="#" class="dropdown-toggle text-white" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Campus Logins <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="https://dmug.brightspace.com/d2l/login" target="_blank"><i class="fa fa-graduation-cap mr-5"></i> LMS Login</a></li>
                    <!--<li><a href="#"><i class="fa fa-edit mr-5"></i> SIS Login</a></a></li>-->
                    <li><a href="https://www.office.com/?auth=2" target="_blank"><i class="fa fa-envelope mr-5"></i> Office 365</a></li> 
                    
                  </ul>
                </li>             
            </ul>
          </div>
        </div>
      </div>
    </div>    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default"><a class="menuzord-brand pull-left flip mt-sm-10 mb-sm-20" href="index.php"><img src="images/logo-dmc.png" alt=""></a>
            <ul class="menuzord-menu">
              <li><a href="index.php">Home</a> 
              </li>
              <li><a href="#">About Us </a>
                <ul class="dropdown">
                <li><a href="main.php?pageid=74&AboutDmcg">About DMCG</a></li>
                <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>				
				 <li><a href="main.php?pageid=13&DeansMessage">Dean's Message</a></li>
				 <li><a href="main.php?pageid=17&BoardTrustees">Board of Trustees</a></li>		 
				 <li><a href="main.php?pageid=73&Leadership">DMCG Leadership</a></li>
                 <li><a href="main.php?pageid=12&VisionMission">The Vision &amp; Mission</a></li>
				 <li><a href="main.php?pageid=16&GoalsObjectives">Goals and Objectives</a></li>	
				 <li><a href="main.php?pageid=15&CollegePublications">College Publications</a></li>
				 <li><a href="main.php?pageid=18&OrganizationStructure">Organization Structure</a></li>			 
				 <li><a href="main.php?pageid=14&AboutDubai">About Dubai</a></li>
                </ul>
              </li>
              <li><a href="#">Academics</a>
                <ul class="dropdown">
                  <li><a href="academics.php?pageid=22&ProgramLearning">MBBCH</a>
                    <ul class="dropdown">
					  <li><a href="#">Calendars</a>
					   <ul class="dropdown">
					   <li><a href="academics.php?pageid=19&AcademicCalendar">Academic Calendar</a></li>
                      <li><a href="academics.php?pageid=20&EventsCalendar">Events Calendar</a></li>
					  <li><a href="academics.php?pageid=85&ExaminationCalendar">Examination Calendar</a></li></ul>
					  </li> 
					  <!--<li><a href="academics.php?pageid=21&ProgramDetails">Program Details</a></li>-->
					  <li><a href="academics.php?pageid=22&ProgramLearning">Program Learning Outcomes</a></li>
					  <li><a href="academics.php?pageid=23&TeachingPlan">Teaching Plan</a></li>
					  <li><a href="academics.php?pageid=24&CourseDescription">Course Description</a></li>
					  <li><a href="academics.php?pageid=79&Timetables">Timetables</a></li>
					  <li><a href="academics.php?pageid=84&CourseCatalogue">Course Catalogue</a></li>
					  <li><a href="academics.php?pageid=87&StudyGuide">Study Guide</a></li>
					  <li><a href="academics.php?pageid=81&GraduationCriteria">Graduation Criteria</a></li>
					  <li><a href="academics.php?pageid=82&AcademicFaculty">Academic Faculty & Staff</a></li>
					  <li><a href="academics.php?pageid=83&AdjunctFaculty">Adjunct Faculty Manual</a></li>
                    </ul>
                  </li>                  
                </ul>
              </li> 
              <li><a href="#">Life At Campus</a>
                <ul class="dropdown">  
                  <li><a href="campus.php?pageid=51&Departments">Departments</a></li>
				  <li><a href="campus.php?pageid=75&StudentAffairs">Student Affairs</a>
                    <ul class="dropdown">                      
				    <li><a href="campus.php?pageid=36&CareerGuidance">Career Guidance</a></li> 
				 	<li><a href="campus.php?pageid=35&StudentCounselling">Student Counselling</a></li> 
				 	<li><a href="campus.php?pageid=76&StudentServices">Student Support Services</a></li> 
				 	<li><a href="campus.php?pageid=34&Hostel">Hostel Facilities</a></li> 			  
                    </ul>
                  </li>
				  <li><a href="campus.php?pageid=80&SimulationCenter">Simulation Center</a></li>
				   <li><a href="campus.php?pageid=32&LearningCenter">Learning Center</a></li>
                  <li><a href="campus.php?pageid=33&FacilitiesDHA">Facilities at DHA</a></li>
<li><a href="campus.php?pageid=78&TeachingFacilities">Teaching Facilities</a></li>
                </ul> 
              </li>
			  <li><a href="#">Research</a>
                <ul class="dropdown"> 
				 <!--<li><a href="research.php?pageid=37&Director+of+Research">Director of Research</a></li>--> 
				 <li><a href="research.php?pageid=38&AimofResearch">Aim of Research at DMCG</a></li>
				 <li><a href="research.php?pageid=39&ResearchCollaborations">Research Collaborations</a></li>
				 <li><a href="research.php?pageid=40&ResearchSupport">Research Support</a></li>
				 <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li>
				  <li><a href="research.php?pageid=42&Publications">DMCG Academic Publications</a></li>
				 <li><a href="research.php?pageid=45&Researchpolicy">Research Policy</a></li>
                </ul>
              </li>
			  <li><a href="#">Library</a>
                <ul class="dropdown">  
                  <li><a href="library.php?pageid=31&DMCGLibrary">DMCG Library</a></li>
				  <li><a href="library.php?pageid=47&EResources">E-Resources</a></li>
				  <li><a href="#">E-Journals</a>
				   <ul class="dropdown">
                      <li><a href="journals1.php">Medline Complete</a></li> 
					  <li><a href="journals3.php">Open Access Journals </a></li>
					  <li><a href="library.php?pageid=49&OtherJournals">Other Journals </a></li>
                    </ul></li>
                </ul> 
              </li>
			  <li class="active"><a href="#">Media</a>
                <ul class="dropdown"> 
                  <li><a href="announcements.php">Announcements</a></li>
                  <!--<li><a href="media.php?nncategory_id=1&News">News</a></li>-->
                  <li><a href="event.php?ecategory_id=1&DMCG Events">Events</a></li>
				 <li><a href="collegem.php">College Magazines</a></li> 
				 <li><a href="event.php?ecategory_id=2&DMCG Updates">DMCG Updates</a></li> 
                </ul>
              </li>
			  <li><a href="contact.php">Contact</a>               
              </li>
            </ul>			
		          </nav>
        </div>
      </div>
    </div>
  </header>
  
 
  
  
 
  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-white-7" data-bg-img="images/bg/bg4.jpg">
      <div class="container pt-50 pb-30">
        <!-- Section Content -->
        <div class="section-title">
          <div class="row"> 
            <div class="col-md-6 text-left flip xs-text-center">
              <h5 class="sub-title">Keep you up to date</h5>
          <h2 class="title">Media</h2>
            </div>
            <div class="col-sm-4">
              <ol class="breadcrumb text-right sm-text-center text-black mt-10">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Media</a></li>
                <li class="active text-theme-colored">Announcements</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
    
	
	
 <!-- Section: Course list -->
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-9 blog-pull-right">
		  <h3 class="text-uppercase line-bottom-theme-colored-2 line-height-1 mt-0 mt-sm-30"> Announcements</h3>    
               
			   
			   
			   
			   
			 


					<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/annual_students_research1.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">03</li>
                      <li class="font-12 text-white text-uppercase">Nov</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=12&1st Annual Students Research and Scientific Day">1st Annual Students Research and Scientific Day</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=12&1st Annual Students Research and Scientific Day"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/Final_Exam_B35_22_23fe.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">27</li>
                      <li class="font-12 text-white text-uppercase">Oct</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=11&Final Exam Schedule of Biomedical Sciences Third Year Batch (35 ) AY 2022-2023">Final Exam Schedule of Biomedical Sciences Third Year Batch (35 ) AY 2022-2023</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=11&Final Exam Schedule of Biomedical Sciences Third Year Batch (35 ) AY 2022-2023"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/Exam_clinical_sciences_ 2022_2023.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">25</li>
                      <li class="font-12 text-white text-uppercase">Oct</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=10&Exam Schedule of Clinical Sciences Academic Year 2022-2023">Exam Schedule of Clinical Sciences Academic Year 2022-2023</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=10&Exam Schedule of Clinical Sciences Academic Year 2022-2023"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/Exam_2022_2023fe.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">25</li>
                      <li class="font-12 text-white text-uppercase">Oct</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=9&Examination Instructions">Examination Instructions</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=9&Examination Instructions"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/Mid-semester_Comprehensive1st-sem-AY-2022-2023.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">14</li>
                      <li class="font-12 text-white text-uppercase">Sep</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=8&Mid Semester Comprehensive Exam Timetable 1st Semester Academic Year 2022-2023">Mid Semester Comprehensive Exam Timetable 1st Semester Academic Year 2022-2023</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=8&Mid Semester Comprehensive Exam Timetable 1st Semester Academic Year 2022-2023"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/1660106875Resit_Exam_1_2_Year_Sep2022-611x1024.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">05</li>
                      <li class="font-12 text-white text-uppercase">Jul</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=7&Resit Exam Timetable - September 2022">Resit Exam Timetable - September 2022</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=7&Resit Exam Timetable - September 2022"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/1660106417Final_Exam_Timetable_July-2022-714x1024.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">10</li>
                      <li class="font-12 text-white text-uppercase">Aug</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=6&Final Exam Timetable July -2022 First & Second Year (Academic Year 2021-2022)">Final Exam Timetable July -2022 First & Second Year (Academic Year 2021-2022)</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=6&Final Exam Timetable July -2022 First & Second Year (Academic Year 2021-2022)"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/1660106344Schedule-of-Practical-Oral-SecondYear-2022-774x1024.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">11</li>
                      <li class="font-12 text-white text-uppercase">May</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=5&Schedule of Practical Exam Semester 2 Second Year (Academic Year 2021-2022)">Schedule of Practical Exam Semester 2 Second Year (Academic Year 2021-2022)</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=5&Schedule of Practical Exam Semester 2 Second Year (Academic Year 2021-2022)"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/1660106231Schedule_of_Practica_Oral_FirstYear-2022.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">11</li>
                      <li class="font-12 text-white text-uppercase">May</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=4&Schedule of Practical and Oral Exam Semester 2 First Year (Academic Year 2021-2022)">Schedule of Practical and Oral Exam Semester 2 First Year (Academic Year 2021-2022)</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=4&Schedule of Practical and Oral Exam Semester 2 First Year (Academic Year 2021-2022)"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/1660105378First_Year_2nd_sem_AY_21_22-1.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">01</li>
                      <li class="font-12 text-white text-uppercase">Mar</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=3&1st & 2nd Year Mid-Year and Mid-semester Comprehensive Exam Timetable">1st & 2nd Year Mid-Year and Mid-semester Comprehensive Exam Timetable</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=3&1st & 2nd Year Mid-Year and Mid-semester Comprehensive Exam Timetable"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/1660105019batch_34_third_resit_result_2021_2022-1024x748.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">26</li>
                      <li class="font-12 text-white text-uppercase">Jan</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=2&Batch 34, Third Year Resit Exam Result 2021-2022">Batch 34, Third Year Resit Exam Result 2021-2022</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=2&Batch 34, Third Year Resit Exam Result 2021-2022"> View now</a>
                </div>
              </article>
            </div>
			
						
									<div class="col-sm-6 col-md-4">
              <article class="post clearfix mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb" style="position: relative; height:280px; overflow: hidden;"> 
                    <img src="images/gallery/1660103834Final_exam_instructions_academic_year_2021_20222-611x1024.jpg" alt="" class="img-responsive img-fullwidth" style="height: auto; overflow:hidden"> 
                  </div>                    
                  <div class="entry-date media-left text-center flip bg-theme-colored border-top-theme-colored2-3px pt-5 pr-15 pb-5 pl-15">
                    <ul>
                      <li class="font-16 text-white font-weight-600">19</li>
                      <li class="font-12 text-white text-uppercase">Jan</li>
                    </ul>
                  </div>
                </div>
                <div class="entry-content p-10">
                  <div class="entry-meta media no-bg no-border mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip" style="height: 65px; max-height:65px ;overflow-y:auto;">
                        <h5 class="entry-title text-white font-weight-400 m-0 mt-5"><a href="announcement.php?id=1&Final Exam Instructions Academic Year 2021-2022">Final Exam Instructions Academic Year 2021-2022</a></h5>                            
                      </div>
                    </div>
                  </div>
                  
                  <a class="btn btn-default btn-flat font-12 mt-10 ml-5" href="announcement.php?id=1&Final Exam Instructions Academic Year 2021-2022"> View now</a>
                </div>
              </article>
            </div>
			
						
				  

          </div>
          <div class="col-md-3">
		  
		  <!-- Left Menu-->
		 <div class="sidebar sidebar-left mt-sm-30">
              <div class="widget">
                 <h5 class="widget-title line-bottom">Media</h5>
				<ul class="list list-divider list-border">  
				<ul class="list list-divider list-border">  
				<li><a href="announcements.php"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> Announcements </a></li>
		 <!--<li><a href="media.php?nncategory_id=1&News"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> News </a></li>-->
		 <li><a href="event.php?ecategory_id=1&DMCG Events"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> Events </a></li>
		 <li><a href="collegem.php"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> College Magazines </a></li>  
		 <li><a href="event.php?ecategory_id=2&DMCG Updates"><i class="fa fa-bookmark-o mr-10 text-black-light"></i> DMCG  Updates </a></li>  
                </ul>                </ul> 
              </div>
               <!-- banner here-->
                
            </div>
            <!-- End Menu-->
          </div>
        </div> 
		
      </div>
    </section>
  </div>
  <!-- end main-content -->
  
  <!-- Footer -->
  <footer id="footer" class="footer fixed-footer" data-bg-color="#212331">
    <div class="container pt-40 pb-10">
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-5 mb-20" alt="" src="images/logo-white-footer.png">
            <p>Muhaisanah 1, Al Mizhar, Dubai.</p>
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">9714-2120555</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored2 mr-5"></i> <a class="text-gray" href="#"> dmcg@dmcg.edu</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">www.dmcg.edu</a> </li>
            </ul>            
            <ul class="styled-icons icon-sm icon-bordered icon-circled clearfix mt-10">
              <li><a href="https://www.facebook.com/dmcg.edu" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/dmc_edu" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/school/dubai-medical-college" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.instagram.com/dubaimedicalcollegeforgirls/" target="_blank"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Useful Links</h4>
            <ul class="angle-double-right list-border">
              <li><a href="academics.php?pageid=21&ProgramDetails">MBBCH Program</a></li>
              <li><a href="main.php?pageid=11&FoundersMessage">Founder's Message</a></li>
              <li><a href="main.php?pageid=12&VisionMission">Vision & Mission</a></li>
              <li><a href="research.php?pageid=41&ResearchStrategy">Research Strategy</a></li> 
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
		    <h4 class="widget-title line-bottom-theme-colored-2">Jobs Vacancies</h4>
            <div class="latest-posts">
			  


              <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Student Counsellor</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Career Guidance & Alumni Affairs</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			                <article class="post media-post clearfix pb-0 mb-10">                
                <div class="post-right">
                  <h5 class="post-title mt-0 mb-5"><a href="jobs.php">Executive Secretary</a></h5>
                  <p class="post-date mb-0 font-12"></p>
                </div>
              </article>
			    
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Opening Hours</h4>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span> Mon - Thu :  </span>
                  <div class="value pull-right"> 7.30 AM to 3.30 PM </div>
                </li>
                <li class="clearfix"> <span> Fri :</span>
                  <div class="value pull-right"> 7.30 AM to 12.00 Noon </div>
                </li> 
                <li class="clearfix"> <span> Sat -Sun : </span>
                  <div class="value pull-right bg-theme-colored2 text-white closed"> Closed </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
	


    <div class="footer-bottom" data-bg-color="#2b2d3b">
      <div class="container pt-5 pb-10">
        <div class="row">
          <div class="col-md-6">
            <p class="font-12 text-black-777 m-0 sm-text-center">Copyright &copy; DMCG. All Rights Reserved. Website updated 13/11/2022</p>
          </div>
          <div class="col-md-6 text-right">
            <div class="widget no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12">
                <li>
                  <a href="#">Terms & Conditions</a>
                </li>
                <li>|</li>
                <li>
                  <a href="dmcg.php?pageid=86&Privacy Policy">Privacy Policy</a>
                </li> 
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>
	<!-- Bootstrap Data Table Plugin -->
	<script src="js/components/bs-datatable.js"></script>
	
 <input type="hidden" name="ids" id="ids" value="1" readonly />
<script type="text/javascript">
 
var chatinput = document.getElementById("ids").value;
if (chatinput == "" || chatinput.length == 0 || chatinput == null)
{
    window.location = "index.php";
}
</script>
<script>

		$(document).ready(function() {
			$('#datatable1').dataTable( {
        "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]]
    });
		});

	</script>
</body>
</html>