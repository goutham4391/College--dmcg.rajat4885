
  
<html>
	<head>
		<script language="javascript">
		function go() {
			var key = document.getElementById("key").value;
			
			if (!isNaN(key)) {
				document.getElementById('submitButton').value=
					"Redirecting to " + document.uptodate.action + " ... please wait.";
				document.uptodate.submit();
			} else {
				alert("This UpToDate portal is not installed correctly.  Please contact your systems administrator");
				return false;
			}
		}
		</script>
	</head>
	 
<body onLoad="redirect()">
		<form method="POST" action="http://www.uptodate.com/" name="uptodate" onSubmit="go();">
		</form>
	</body>
<script language=javascript>
function redirect(){
  window.location = "http://www.uptodate.com/";
}
</script>	
</html>
